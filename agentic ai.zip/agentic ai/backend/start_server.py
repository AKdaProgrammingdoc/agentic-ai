import os, subprocess, sys, time
proc = subprocess.Popen(
    [sys.executable, "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", "8000"],
    cwd=os.path.dirname(os.path.abspath(__file__)),
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)
print(f"Server started with PID {proc.pid}")
time.sleep(2)
print("Running on http://127.0.0.1:8000")
