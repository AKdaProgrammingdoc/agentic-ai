
window.addEventListener('load',function(){var f=document.getElementById('mikuFront');if(!f||window.matchMedia('(max-width: 700px)').matches)return;f.classList.add('show');setTimeout(function(){f.classList.add('gone')},8200);});
