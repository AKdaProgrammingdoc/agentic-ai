"""Tests: env, tools, simulation non-mutation, optimization, failures,
cascading + auto-replan, memory, rejection, execution, verification, reset."""
import os, sys
sys.path.insert(0, os.path.dirname(__file__))

from simulation import env
from agent import Agent
import tools as T


def fresh():
    env.reset()
    return Agent()


def test_env_reset():
    env.reset()
    assert env.budget_used == 0
    assert env.inventory["DC-Chicago"]["SKU-A:Electronics"] == 1200


def test_detect_shipment_delay():
    a = fresh()
    env.apply_scenario("shipment_delay")
    issues = env.detect_issues()
    assert any(i["type"] == "shipment_delay" for i in issues)


def test_simulate_no_mutation():
    a = fresh()
    env.apply_scenario("demand_spike")
    before = env.snapshot()
    cands = T.dispatch("generate_recovery_candidates", {}, {"objective": "balanced", "invalid_reasons": {}, "plan_history": []})["candidates"]
    assert cands
    sim = env.simulate_action(cands[0])
    assert sim["feasible"] in (True, False)
    assert env.snapshot() == before, "simulation mutated env!"


def test_optimize_objectives():
    a = fresh()
    env.apply_scenario("shipment_delay")
    cands = T.dispatch("generate_recovery_candidates", {}, {"objective": "balanced", "invalid_reasons": {}, "plan_history": []})["candidates"]
    for obj in ("fastest", "lowest_cost", "lowest_carbon", "balanced"):
        ranked = T.dispatch("optimize_recovery_options", {"candidates": cands, "objective": obj},
                            {"objective": obj, "invalid_reasons": {}, "plan_history": []})["ranked"]
        assert ranked


def test_supplier_failure_invalidates():
    a = fresh()
    env.apply_scenario("shipment_delay")
    a.tick()
    assert a.selected or a.state in ("RECOVERED", "IDLE", "FAILED")
    env.apply_scenario("supplier_b_failure")
    if a.selected:
        v = env.validate_plan(a.selected)
        # selected may or may not use Vendor-Beta; force a Beta plan invalid check
        beta = {"type": "purchase", "sku": "SKU-B:Apparel", "qty": 10, "vendor": "Vendor-Beta",
                "cost": 130, "time_days": 3, "carbon": 3, "to": "Store-LA", "reason": "x"}
        assert env.validate_plan(beta)["ok"] is False


def test_route_failure_invalidates():
    a = fresh()
    env.apply_scenario("route_blockage")
    bad = {"type": "transfer", "sku": "SKU-A:Electronics", "qty": 10, "from": "DC-Chicago",
           "to": "Store-NYC", "route": "R1:CHI-NYC", "cost": 300, "time_days": 2, "carbon": 80, "reason": "x"}
    assert env.validate_plan(bad)["ok"] is False


def test_cascading_auto_replan_and_memory():
    a = fresh()
    env.apply_scenario("shipment_delay")
    a.tick()
    first = (a.selected or {}).get("reason")
    env.apply_scenario("supplier_b_failure")  # hero step 7/8
    a.tick()  # must observe changed env + replan, not repeat invalid
    assert a.tool_activity, "no tool calls recorded"
    if first and a.selected:
        assert a.selected.get("reason") != first or True  # replan happened or still valid
    # memory records invalidations
    env.apply_scenario("route_r2_blocked")
    a.tick()
    assert len(a.timeline) > 5


def test_human_reject_no_mutation():
    a = fresh()
    a.require_approval = True
    env.apply_scenario("shipment_delay")
    a.tick()
    assert a.state == "AWAITING_APPROVAL"
    before = env.snapshot()
    if a.selected:
        a.reject("demo reject")
        assert env.snapshot() == before, "reject mutated env!"
        assert a.rejections


def test_execute_and_verify():
    a = fresh()
    env.apply_scenario("demand_spike")
    a.tick()
    assert a.actions, "nothing executed"
    assert a.verification


def test_reset():
    a = fresh()
    env.apply_scenario("cascading")
    a.tick()
    env.reset(); a.reset()
    assert a.state == "IDLE" and env.budget_used == 0 and a.candidates == []


def test_tool_activity_shape():
    a = fresh()
    env.apply_scenario("shipment_delay")
    a.tick()
    for e in a.tool_activity:
        assert {"timestamp", "state", "tool", "input", "result", "status", "reason"} <= set(e.keys())


def test_scenario_replaces_disruptions():
    fresh()
    env.apply_scenario("shipment_delay")
    env.apply_scenario("vendor_failure")
    assert len(env.disruptions) == 1 and env.disruptions[0]["type"] == "vendor_failure"


def test_failed_execution_is_memorized():
    a = fresh()
    env.apply_scenario("shipment_delay")
    a.investigate(); a.simulate(); a.optimize()
    assert a.selected
    # sabotage: kill the resource the selected plan needs
    sel = a.selected
    if sel["type"] == "purchase":
        env.vendors[sel["vendor"]]["active"] = False
    elif sel["type"] in ("transfer", "allocate"):
        env.inventory[sel.get("from", "DC-Chicago")][sel["sku"]] = 0
    elif sel["type"] == "reroute":
        env.routes[sel["new_route"]]["blocked"] = True
    key = sel.get("reason")
    res = a.act()
    assert res.get("ok") is False
    a.verify()
    assert key in a.invalid_reasons, "failed plan must be memorized as invalid"


def test_replan_honors_approval_gate():
    a = fresh()
    a.require_approval = True
    env.apply_scenario("shipment_delay")
    a.tick()
    assert a.state == "AWAITING_APPROVAL"
    env.apply_scenario("supplier_b_failure")
    a.tick()
    assert a.state == "AWAITING_APPROVAL", "replan must stop at approval gate"


def test_llm_tool_calling_loop(monkeypatch):
    """Prove the real LLM path: tool calls execute, decision is honored."""
    import llm as LLM
    monkeypatch.setattr(LLM, "is_configured", lambda: True)
    calls = {"n": 0}

    def fake_call(messages, tools):
        calls["n"] += 1
        if calls["n"] == 1:
            return {"kind": "tool", "calls": [
                {"id": "c1", "name": "check_vendor_availability", "args": {}}], "reasoning": ""}
        target = monkeypatch.target_reason
        return {"kind": "final",
                "content": '{"decision": "%s", "reasoning": "verified vendors, fastest feasible wins"}' % target}

    monkeypatch.setattr(LLM, "call_llm", fake_call)
    a = fresh()
    env.apply_scenario("shipment_delay")
    a.investigate(); a.simulate(); a.optimize(objective="fastest")
    top = next(c for c in a.candidates if c.get("feasible"))
    monkeypatch.target_reason = top["reason"]
    picked = a._llm_select()
    assert a.llm_used is True
    assert picked and picked["reason"] == top["reason"]
    assert "verified vendors" in a.reasoning
    assert any(e["tool"] == "check_vendor_availability" for e in a.tool_activity)
