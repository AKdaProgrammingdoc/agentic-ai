import os, sys
sys.path.insert(0, os.path.dirname(__file__))

from fastapi.testclient import TestClient
from main import app

c = TestClient(app)

r = c.get('/')
print("Status:", r.status_code)
print("Has setObjective:", "setObjective" in r.text)
print("Has runAgent:", "runAgent" in r.text)
print("Has currentObjective:", "currentObjective" in r.text)
print("Has api/state:", "/api/state" in r.text)
print("Has tick:", "tick()" in r.text)
print("Has reset:", "reset()" in r.text)
print("Has scenario:", "scenario(" in r.text)
print("Frontend served correctly!" if r.status_code == 200 else "PROBLEM!")
