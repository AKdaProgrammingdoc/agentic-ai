import re
src = open("D:\\69\\agentic ai\\frontend\\index.html", encoding="utf-8").read()
blocks = re.findall(r"<script>(.*?)</script>", src, re.S)
print("inline_blocks:" + str(len(blocks)))
for i, b in enumerate(blocks):
    open("D:\\69\\agentic ai\\backend\\_chk%d.js" % i, "w", encoding="utf-8").write(b)
    print("block%d_len:%d" % (i, len(b)))
