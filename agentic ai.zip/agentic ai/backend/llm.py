"""Configurable LLM provider (OpenAI-compatible) with structured tool calling.

Env vars:
  LLM_API_KEY  - required for real agentic reasoning
  LLM_MODEL    - default gpt-4o-mini
  LLM_BASE_URL - default https://api.openai.com/v1

If no key is set the agent fails gracefully to a deterministic fallback
planner and NEVER fakes an AI response (timeline is labeled accordingly).
"""
import json
import os
import urllib.request
from typing import Any, Dict, List

try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
except ImportError:
    pass


def config() -> Dict[str, str]:
    return {
        "api_key": os.getenv("LLM_API_KEY", ""),
        "model": os.getenv("LLM_MODEL", "gpt-4o-mini"),
        "base_url": os.getenv("LLM_BASE_URL", "https://api.openai.com/v1").rstrip("/"),
    }


def is_configured() -> bool:
    return bool(config()["api_key"])


SYSTEM = ("You are an autonomous retail supply-chain recovery agent. "
          "You reason about disruptions and MUST use tools to gather facts. "
          "Never invent inventory, vendor, route, cost, ETA or carbon values — "
          "always call tools. Prefer the fastest feasible plan when asked for fastest, "
          "cheapest for lowest_cost, greenest for lowest_carbon. "
          "Avoid any candidate listed in plan history as INVALIDATED. "
          "Respond with a tool call when you need data, otherwise respond with JSON "
          "{\"decision\": <candidate-reason or null>, \"reasoning\": \"...\", \"need_more\": true/false}.")


def _post(url: str, payload: Dict[str, Any], key: str, timeout: int = 25) -> Dict[str, Any]:
    headers = {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}
    if "openrouter.ai" in url:
        headers["HTTP-Referer"] = os.getenv("OPENROUTER_REFERER", "http://127.0.0.1:8000")
        headers["X-Title"] = os.getenv("OPENROUTER_TITLE", "Retail Supply Chain Recovery Agent")
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode())


def call_llm(messages: List[Dict[str, Any]], tools: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Single LLM step. Returns {kind: 'tool'|'final', ...}. Raises RuntimeError if unavailable."""
    cfg = config()
    if not cfg["api_key"]:
        raise RuntimeError("LLM_API_KEY not set")
    functions = [{
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t.get("description", ""),
            "parameters": {
                "type": "object",
                "properties": {
                    "shipment_id": {"type": "string"},
                    "vendor": {"type": "string"},
                    "route": {"type": "string"},
                    "candidate": {"type": "object"},
                    "candidates": {"type": "array"},
                    "objective": {"type": "string"},
                    "expected": {"type": "object"},
                },
            },
        },
    } for t in tools]
    payload = {"model": cfg["model"], "temperature": 0.2,
               "messages": [{"role": "system", "content": SYSTEM}] + messages,
               "tools": functions, "tool_choice": "auto"}
    try:
        data = _post(cfg["base_url"] + "/chat/completions", payload, cfg["api_key"])
    except Exception as e:
        raise RuntimeError(f"LLM call failed: {e}")
    try:
        msg = data["choices"][0]["message"]
    except Exception as e:
        raise RuntimeError(f"LLM bad response: {e} :: {str(data)[:400]}")
    tcs = msg.get("tool_calls") or []
    if tcs:
        calls = []
        for tc in tcs:
            fn = tc.get("function", {})
            try:
                args = json.loads(fn.get("arguments") or "{}")
            except Exception:
                args = {}
            calls.append({"id": tc.get("id"), "name": fn.get("name"), "args": args})
        return {"kind": "tool", "calls": calls, "reasoning": msg.get("content") or ""}
    return {"kind": "final", "content": msg.get("content") or ""}
