import os, sys
sys.path.insert(0, os.path.dirname(__file__))

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

import llm as LLM
print("Configured:", LLM.is_configured())
print("Model:", LLM.config()["model"])

# Test LLM call
messages = [{"role": "user", "content": "What is the capital of France? Just reply with the answer."}]
try:
    result = LLM.call_llm(messages, [])
    print("LLM result:", result)
except Exception as e:
    print("LLM error:", type(e).__name__, str(e)[:200])
