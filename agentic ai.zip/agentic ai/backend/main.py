"""FastAPI backend. Existing frontend contract preserved exactly.
New endpoints are additive only (frontend files modified = 0).
"""
import asyncio
import os
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import simulation
import agent as ag
import llm as LLM

AUTONOMOUS = os.getenv("AUTONOMOUS_LOOP", "0") == "1"
AUTONOMOUS_INTERVAL = float(os.getenv("MONITOR_INTERVAL_SEC", "5"))


async def _autonomous_loop():
    """Server-side monitor: detect + recover without any frontend clicks.
    The existing UI picks everything up via its normal polling."""
    while True:
        await asyncio.sleep(AUTONOMOUS_INTERVAL)
        try:
            if ag.agent.require_approval or ag.agent.state == "AWAITING_APPROVAL":
                continue
            if simulation.env.detect_issues():
                ag.agent.tick()
        except Exception as e:
            ag.agent.timeline.append({"step": len(ag.agent.timeline) + 1, "phase": "ADAPT",
                                      "msg": f"Autonomous loop error: {e}", "ts": 0})


@asynccontextmanager
async def lifespan(app: FastAPI):
    task = None
    if AUTONOMOUS:
        task = asyncio.create_task(_autonomous_loop())
    yield
    if task:
        task.cancel()


app = FastAPI(title="Retail Supply Chain Recovery Agent", lifespan=lifespan)
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def no_cache_html(request, call_next):
    resp = await call_next(request)
    if request.url.path in ("/", "/index.html"):
        resp.headers["Cache-Control"] = "no-store"
    return resp


def state_payload():
    snap = simulation.env.snapshot()
    a = ag.agent
    return {
        "env": snap,
        "service_level": simulation.env.service_level(),
        "can_fulfill": simulation.env.can_fulfill(),
        "agent": {
            "goal": a.goal,
            "objective": a.objective,
            "state": a.state,
            "disruption": a.disruption,
            "previous_plan": a.previous_plan,
            "current_plan": a.current_plan,
            "selected": a.selected,
            "candidates": a.candidates,
            "actions": a.actions[-5:],
            "failures": a.failures,
            "verification": a.verification,
            "timeline": a.timeline,
            "step": a.step,
            "llm_used": a.llm_used,
            "reasoning": a.reasoning,
        },
    }


# ---- existing contract (unchanged shapes) ----
@app.get("/api/state")
def state():
    return state_payload()


@app.post("/api/scenario/{name}")
def scenario(name: str):
    simulation.env.apply_scenario(name)
    label = ag.SCENARIO_WORDS.get(name, name.replace("_", " "))
    ag.agent.timeline.append({"step": len(ag.agent.timeline) + 1, "phase": "SCENARIO",
                              "msg": f"What happened: {label}.", "ts": 0})
    # a new disruption invalidates a stale selection via memory
    if ag.agent.selected:
        v = simulation.env.validate_plan(ag.agent.selected)
        if not v["ok"]:
            ag.agent._invalidate_selected("; ".join(v["reasons"]))
    return state_payload()


@app.post("/api/agent/tick")
def tick(body: Optional[dict] = None):
    objective = (body or {}).get("objective") if isinstance(body, dict) else None
    r = ag.agent.tick(objective=objective)
    return {"tick_result": r, **state_payload()}


@app.post("/api/agent/run")
def run(body: Optional[dict] = None):
    objective = (body or {}).get("objective") if isinstance(body, dict) else None
    out = []
    for _ in range(6):
        r = ag.agent.tick(objective=objective)
        out.append(r)
        if not simulation.env.disruptions and ag.agent.state == "IDLE":
            break
        if ag.agent.state in ("AWAITING_APPROVAL", "RECOVERED", "FAILED"):
            break
        if not ag.agent.selected:
            break
        if simulation.env.can_fulfill():
            break
    return {"runs": out, **state_payload()}


@app.post("/api/reset")
def reset():
    simulation.env.reset()
    ag.agent.reset()
    return state_payload()


@app.get("/api/health")
def health():
    return {"ok": True}


# ---- additive endpoints (new; frontend untouched) ----
@app.get("/api/monitor")
def monitor():
    """Autonomous monitoring: inspect real env, detect violations."""
    m = ag.agent.monitor()
    return {"ok": True, "state": m["state"], "issues": m["issues"],
            "disruption": m["disruption"], "service_level": m["service_level"],
            "llm_configured": LLM.is_configured()}


@app.get("/api/environment")
def environment():
    return {"ok": True, **simulation.env.snapshot(), "service_level": simulation.env.service_level()}


@app.get("/api/agent")
def agent_info():
    a = ag.agent
    return {"ok": True, "state": a.state, "objective": a.objective, "disruption": a.disruption,
            "selected": a.selected, "candidates": a.candidates, "reasoning": a.reasoning,
            "llm_used": a.llm_used, "llm_configured": LLM.is_configured(),
            "require_approval": a.require_approval}


@app.get("/api/history")
def history():
    a = ag.agent
    return {"ok": True, "timeline": a.timeline, "tool_activity": a.tool_activity,
            "plan_history": a.plan_history, "actions": a.actions,
            "rejections": a.rejections, "verification": a.verification}


@app.get("/api/analysis")
def analysis():
    a = ag.agent
    return {"ok": True, "service_level": simulation.env.service_level(),
            "can_fulfill": simulation.env.can_fulfill(), "objective": a.objective,
            "candidates": a.candidates, "selected": a.selected,
            "reasoning": a.reasoning, "llm_used": a.llm_used,
            "plan_history": a.plan_history}


class ObjectiveBody(BaseModel):
    objective: str = "balanced"


@app.post("/api/agent/objective")
def set_objective(b: ObjectiveBody):
    ag.agent.objective = b.objective
    return {"ok": True, "objective": ag.agent.objective}


class ApprovalBody(BaseModel):
    require_approval: bool = True


@app.post("/api/agent/require_approval")
def require_approval(b: ApprovalBody):
    ag.agent.require_approval = b.require_approval
    return {"ok": True, "require_approval": ag.agent.require_approval}


@app.post("/api/approve")
def approve():
    r = ag.agent.approve()
    return {**r, **state_payload()}


class RejectBody(BaseModel):
    reason: str = "human_rejected"


@app.post("/api/reject")
def reject(b: RejectBody):
    r = ag.agent.reject(b.reason)
    return {**r, **state_payload()}


@app.post("/api/execute")
def execute():
    r = ag.agent.approve()
    return {**r, **state_payload()}


@app.get("/api/llm")
def llm_status():
    c = LLM.config()
    return {"ok": True, "configured": LLM.is_configured(), "model": c["model"],
            "base_url": c["base_url"], "llm_used_last": ag.agent.llm_used}


@app.get("/api/autonomy")
def autonomy():
    return {"ok": True, "autonomous_loop": AUTONOMOUS, "interval_sec": AUTONOMOUS_INTERVAL,
            "require_approval": ag.agent.require_approval, "state": ag.agent.state}


# serve frontend (unchanged)
frontend = os.path.join(os.path.dirname(__file__), "..", "frontend")
if os.path.isdir(frontend):
    app.mount("/", StaticFiles(directory=frontend, html=True), name="static")
