import os, json, urllib.request, urllib.error
from dotenv import load_dotenv
load_dotenv("D:\\69\\agentic ai\\backend\\.env")
key = os.getenv("LLM_API_KEY")
print("key_prefix:" + (key[:8] if key else "NONE"))
url = "https://api.groq.com/openai/v1/chat/completions"
payload = {"model": "llama-3.3-70b-versatile", "messages": [{"role": "user", "content": "Say hi"}], "max_tokens": 5}
req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json", "Authorization": "Bearer " + key})
try:
    with urllib.request.urlopen(req, timeout=15) as r:
        print("SUCCESS:" + r.read().decode()[:200])
except urllib.error.HTTPError as e:
    print("HTTP:" + str(e.code) + ":" + e.read().decode()[:300])
except Exception as e:
    print("ERR:" + type(e).__name__ + ":" + str(e)[:200])
