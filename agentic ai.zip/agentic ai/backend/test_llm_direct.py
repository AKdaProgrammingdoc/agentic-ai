import os, sys
sys.path.insert(0, os.path.dirname(__file__))

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

import llm as LLM

print("Is configured:", LLM.is_configured())
print("Config:", LLM.config())

# Test direct LLM call
messages = [{"role": "user", "content": "Test"}]
tools = [{"name": "test_tool", "description": "test", "parameters": {"type": "object", "properties": {}}}]

try:
    result = LLM.call_llm(messages, tools)
    print("LLM result:", result)
except Exception as e:
    print("LLM error:", type(e).__name__, str(e)[:200])
