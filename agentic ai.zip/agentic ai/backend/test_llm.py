import os, sys
sys.path.insert(0, os.path.dirname(__file__))

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))
print("API_KEY:", os.getenv("LLM_API_KEY", "NOT SET")[:10] + "..." if os.getenv("LLM_API_KEY") else "NOT SET")
print("Model:", os.getenv("LLM_MODEL"))
print("Base URL:", os.getenv("LLM_BASE_URL"))

import llm as LLM
print("LLM configured:", LLM.is_configured())
print("LLM config:", LLM.config())

from main import app, state_payload
print("state_payload test...")
from fastapi.testclient import TestClient
c = TestClient(app)
r = c.post('/api/agent/run', json={'objective': 'balanced'})
d = r.json()
print("State:", d['agent']['state'])
print("LLM used:", d['agent'].get('llm_used'))
print("Reasoning:", d['agent'].get('reasoning'))
print("Timeline last 3 phases:", [t['phase'] for t in d['agent']['timeline'][-3:]])
