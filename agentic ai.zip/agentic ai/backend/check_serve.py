from urllib.request import urlopen
h = urlopen('http://127.0.0.1:8000/').read().decode()
print("=== CHECKING INDEX.HTML SERVED ===")
print("contains runAgent:", "runAgent" in h)
print("contains currentObjective:", "currentObjective" in h)
print("contains setObjective:", "setObjective" in h)
print("contains api function:", "async function api" in h)
print("contains refresh:", "async function refresh" in h)
print("closes app:", h.rstrip().endswith('</body></html>'))
print("has grid:", 'class="grid"' in h)
print("has pipeline:", 'class="pipeline"' in h)
print("has hero section:", '<section class="hero">' in h)
print("total lines:", h.count(chr(10)))
# Check for any obvious JS syntax issues
if "let currentObjective" in h:
    print("OK: currentObjective declared")
else:
    print("FAIL: currentObjective NOT declared")
# Count script blocks
import re
scripts = h.split('<script>')
print("script blocks:", len(scripts))
# Check the last script block for the api/refresh/render functions
last_script = scripts[-2] if len(scripts) > 1 else ""
for func in ['async function api', 'async function refresh', 'function render', 'async function runAgent', 'async function setObjective']:
    if func in last_script:
        print(f"OK: {func}")
    else:
        print(f"FAIL: {func} not in last script block")
