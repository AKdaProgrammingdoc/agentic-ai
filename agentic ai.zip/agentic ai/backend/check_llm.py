import httpx
r = httpx.get('http://127.0.0.1:8000/api/llm')
print("LLM status:", r.json())
