from fastapi.testclient import TestClient
import main
c = TestClient(main.app)
c.post('/api/reset')
c.post('/api/scenario/shipment_delay')
# Test exactly what the browser does: POST to /api/agent/run with body
r = c.post('/api/agent/run', json={'objective': 'fastest'})
print("Status:", r.status_code)
print("State:", r.json()['agent']['state'])
# Also test refresh (GET /api/state)
s = c.get('/api/state').json()
print("Refresh works:", 'env' in s)
# Test tick
t = c.post('/api/agent/tick', json={'objective': 'fastest'}).json()
print("Tick state:", t['agent']['state'])
# Test tick WITHOUT body (what the browser originally did)
t2 = c.post('/api/agent/tick').json()
print("Tick without body state:", t2['agent']['state'])
print("ALL_OK")
