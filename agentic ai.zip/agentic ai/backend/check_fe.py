from urllib.request import urlopen
h = urlopen('http://127.0.0.1:8000/').read().decode()
checks = [
    ('setObjective', 'setObjective' in h),
    ('Plans Attempted', 'Plans Attempted' in h),
    ('obj id', 'id="obj"' in h),
    ('grid class', 'class="grid"' in h),
    ('pipeline class', 'class="pipeline"' in h),
    ('beforeAfter fix', 'Stock moved' in h),
    ('closes app', h.rstrip().endswith('</body></html>')),
    ('has hero section', '<section class="hero">' in h),
    ('has main', '<div class="main">' in h),
    ('has aside rail', '<aside class="rail">' in h),
]
for name, ok in checks:
    print(('OK  ' if ok else 'FAIL ') + name)
print('total lines:', h.count(chr(10)))
