"""Deterministic mutable supply-chain environment.

Source of truth for inventory, shipments, vendors, routes, demand,
budget, cost, ETA, carbon, capacity, feasibility.
LLM may reason ABOUT these values but never invents them.
"""
import time
import copy
import random
from typing import Dict, List, Any


SKU = ["SKU-A:Electronics", "SKU-B:Apparel", "SKU-C:Grocery"]
STORES = ["Store-NYC", "Store-LA"]
DCS = ["DC-Chicago"]

INIT_INV = {
    "DC-Chicago": {"SKU-A:Electronics": 1200, "SKU-B:Apparel": 2000, "SKU-C:Grocery": 1500},
    "Store-NYC": {"SKU-A:Electronics": 120, "SKU-B:Apparel": 200, "SKU-C:Grocery": 90},
    "Store-LA": {"SKU-A:Electronics": 80, "SKU-B:Apparel": 150, "SKU-C:Grocery": 110},
}
VENDOR_DATA = {
    "Vendor-Alpha": {"sku": "SKU-A:Electronics", "capacity": 800, "cost": 12, "lead_days": 2, "carbon": 45, "reliability": 0.95, "active": True},
    "Vendor-Beta": {"sku": "SKU-B:Apparel", "capacity": 1200, "cost": 8, "lead_days": 3, "carbon": 30, "reliability": 0.92, "active": True},
    "Vendor-Gamma": {"sku": "SKU-C:Grocery", "capacity": 1000, "cost": 5, "lead_days": 1, "carbon": 20, "reliability": 0.88, "active": True},
}
ROUTE_DATA = {
    "R1:CHI-NYC": {"from": "DC-Chicago", "to": "Store-NYC", "cost": 300, "time_days": 2, "carbon": 80, "capacity": 1000, "blocked": False},
    "R2:CHI-LA": {"from": "DC-Chicago", "to": "Store-LA", "cost": 500, "time_days": 3, "carbon": 120, "capacity": 1000, "blocked": False},
    "R3:NYC-LA": {"from": "Store-NYC", "to": "Store-LA", "cost": 250, "time_days": 2, "carbon": 60, "capacity": 500, "blocked": False},
}
SHIPMENTS_INIT = [
    {"id": "SHP-001", "sku": "SKU-A:Electronics", "qty": 200, "route": "R1:CHI-NYC", "status": "in_transit", "eta_days": 2, "vendor": "Vendor-Alpha"},
    {"id": "SHP-002", "sku": "SKU-B:Apparel", "qty": 300, "route": "R2:CHI-LA", "status": "in_transit", "eta_days": 3, "vendor": "Vendor-Beta"},
]
DEMAND_INIT = {
    "Store-NYC": {"SKU-A:Electronics": 180, "SKU-B:Apparel": 220, "SKU-C:Grocery": 150},
    "Store-LA": {"SKU-A:Electronics": 140, "SKU-B:Apparel": 180, "SKU-C:Grocery": 130},
}

BUDGET = 50000


class Env:
    def __init__(self, seed: int = 42):
        self.seed = seed
        self.rng = random.Random(seed)
        self.reset()

    def reset(self):
        self.inventory = copy.deepcopy(INIT_INV)
        self.vendors = copy.deepcopy(VENDOR_DATA)
        self.routes = copy.deepcopy(ROUTE_DATA)
        self.shipments = copy.deepcopy(SHIPMENTS_INIT)
        self.demand = copy.deepcopy(DEMAND_INIT)
        self.budget = BUDGET
        self.budget_used = 0
        self.tick = 0
        self.disruptions: List[Dict[str, Any]] = []
        self.history: List[Dict[str, Any]] = []
        self.rng = random.Random(self.seed)

    def snapshot(self) -> Dict[str, Any]:
        return copy.deepcopy({
            "inventory": self.inventory,
            "vendors": self.vendors,
            "routes": self.routes,
            "shipments": self.shipments,
            "demand": self.demand,
            "budget": self.budget,
            "budget_used": self.budget_used,
            "tick": self.tick,
            "disruptions": self.disruptions,
        })

    # ---------- deterministic scenario injection (manual, for demo) ----------
    def apply_scenario(self, name: str) -> List[Dict[str, Any]]:
        self.disruptions = []  # each injection replaces the active disruption set
        t = int(time.time() * 1000) % 10000
        if name == "shipment_delay":
            for s in self.shipments:
                if s["id"] == "SHP-001":
                    s["status"] = "delayed"
                    s["eta_days"] = 6
                    s["delay_reason"] = "Weather delay at CHI hub"
            self.disruptions.append({"type": "shipment_delay", "target": "SHP-001",
                                     "severity": "high", "desc": "SHP-001 delayed 4 extra days (weather)", "time": t})
        elif name == "vendor_failure":
            self.vendors["Vendor-Alpha"]["active"] = False
            self.vendors["Vendor-Alpha"]["capacity"] = 0
            self.disruptions.append({"type": "vendor_failure", "target": "Vendor-Alpha",
                                     "severity": "critical", "desc": "Vendor-Alpha factory outage - capacity 0", "time": t})
        elif name == "supplier_b_failure":
            # hero step 7: Supplier B fails (alias Vendor-Beta)
            self.vendors["Vendor-Beta"]["active"] = False
            self.vendors["Vendor-Beta"]["capacity"] = 0
            self.disruptions.append({"type": "vendor_failure", "target": "Vendor-Beta",
                                     "severity": "critical", "desc": "Vendor-Beta (Supplier B) failed - capacity 0", "time": t})
        elif name == "route_blockage":
            self.routes["R1:CHI-NYC"]["blocked"] = True
            self.routes["R1:CHI-NYC"]["capacity"] = 0
            self.disruptions.append({"type": "route_blockage", "target": "R1:CHI-NYC",
                                     "severity": "high", "desc": "R1 CHI-NYC blocked (bridge closure)", "time": t})
        elif name == "route_r2_blocked":
            # hero step 13: selected route becomes unavailable
            self.routes["R2:CHI-LA"]["blocked"] = True
            self.routes["R2:CHI-LA"]["capacity"] = 0
            self.disruptions.append({"type": "route_blockage", "target": "R2:CHI-LA",
                                     "severity": "high", "desc": "R2 CHI-LA blocked (hero step 13)", "time": t})
        elif name == "demand_spike":
            self.demand["Store-NYC"]["SKU-A:Electronics"] = 420
            self.disruptions.append({"type": "demand_spike", "target": "Store-NYC SKU-A",
                                     "severity": "high", "desc": "Demand spike NYC SKU-A 180->420 (+133%)", "time": t})
        elif name == "cascading":
            # deterministic hero initial state: shipment delay only.
            # Follow-on failures (Supplier B, route) are injected stepwise
            # via supplier_b_failure / route_r2_blocked for the 22-step demo.
            for s in self.shipments:
                if s["id"] == "SHP-001":
                    s["status"] = "delayed"
                    s["eta_days"] = 7
            self.demand["Store-LA"]["SKU-B:Apparel"] = 400
            self.disruptions.append({"type": "cascading", "target": "multiple", "severity": "critical",
                                     "desc": "Cascading start: SHP-001 delayed + LA demand spike (B-failure & route-block armed for stepwise demo)", "time": t})
        elif name == "cascading_full":
            # legacy all-at-once variant
            for s in self.shipments:
                if s["id"] == "SHP-001":
                    s["status"] = "delayed"
                    s["eta_days"] = 7
            self.vendors["Vendor-Beta"]["active"] = False
            self.vendors["Vendor-Beta"]["capacity"] = 0
            self.routes["R2:CHI-LA"]["blocked"] = True
            self.demand["Store-LA"]["SKU-B:Apparel"] = 400
            self.disruptions.append({"type": "cascading", "target": "multiple", "severity": "critical",
                                     "desc": "Cascading: SHP-001 delayed + Vendor-Beta down + R2 blocked + LA demand spike", "time": t})
        else:
            self.disruptions.append({"type": name, "target": "unknown", "severity": "info",
                                     "desc": f"Unknown scenario '{name}' recorded", "time": t})
        self.tick += 1
        self.history.append({"tick": self.tick, "scenario": name, "disruptions": copy.deepcopy(self.disruptions)})
        return copy.deepcopy(self.disruptions)

    # ---------- derived state (backend is source of truth) ----------
    def service_level(self) -> Dict[str, float]:
        sl = {}
        for store, dem in self.demand.items():
            for sku, d in dem.items():
                inv = self.inventory.get(store, {}).get(sku, 0)
                sl[f"{store}/{sku}"] = round(min(1, inv / max(1, d)), 2)
        return sl

    def can_fulfill(self) -> bool:
        return all(v >= 0.9 for v in self.service_level().values())

    def detect_issues(self) -> List[Dict[str, Any]]:
        """Deterministic monitoring inspection used by GET /api/monitor."""
        issues: List[Dict[str, Any]] = []
        for k, v in self.service_level().items():
            if v < 0.9:
                issues.append({"type": "stockout_risk", "target": k, "sl": v, "severity": "high" if v < 0.7 else "medium"})
        for s in self.shipments:
            if s["status"] == "delayed":
                issues.append({"type": "shipment_delay", "target": s["id"], "severity": "high", "detail": copy.deepcopy(s)})
        for vname, vd in self.vendors.items():
            if not vd["active"]:
                issues.append({"type": "vendor_failure", "target": vname, "severity": "critical"})
        for rname, rd in self.routes.items():
            if rd["blocked"]:
                issues.append({"type": "route_blockage", "target": rname, "severity": "high"})
        for store in self.demand:
            for sku, dem in self.demand[store].items():
                inv = self.inventory.get(store, {}).get(sku, 0)
                if dem > inv * 1.5:
                    issues.append({"type": "demand_spike", "target": f"{store}/{sku}",
                                   "demand": dem, "inv": inv, "severity": "high"})
        return issues

    # ---------- validation (before execution) ----------
    def validate_plan(self, action: Dict[str, Any]) -> Dict[str, Any]:
        reasons: List[str] = []
        typ = action.get("type")
        qty = action.get("qty", 0)
        sku = action.get("sku")
        cost = action.get("cost", 0)
        if self.budget_used + cost > self.budget:
            reasons.append(f"budget_exceeded: need ${cost}, used ${self.budget_used}/${self.budget}")
        if qty <= 0:
            reasons.append("non_positive_qty")
        if typ == "purchase":
            v = action.get("vendor")
            vd = self.vendors.get(v)
            if not vd or not vd["active"]:
                reasons.append(f"vendor_inactive: {v}")
            elif qty > vd["capacity"]:
                reasons.append(f"vendor_capacity: need {qty}, cap {vd['capacity']}")
            elif vd["sku"] != sku:
                reasons.append("sku_mismatch")
        elif typ == "transfer":
            src = action.get("from")
            route = action.get("route")
            rd = self.routes.get(route) if route else None
            if rd and rd["blocked"]:
                reasons.append(f"route_blocked: {route}")
            if qty > self.inventory.get(src, {}).get(sku, 0):
                reasons.append(f"insufficient_inventory at {src}: have {self.inventory.get(src, {}).get(sku, 0)}")
            if rd and qty > rd["capacity"]:
                reasons.append(f"route_capacity: need {qty}, cap {rd['capacity']}")
        elif typ == "allocate":
            if qty > self.inventory.get("DC-Chicago", {}).get(sku, 0):
                reasons.append("insufficient_dc_inventory")
        elif typ == "reroute":
            shp = action.get("shipment_id")
            new_route = action.get("new_route")
            rd = self.routes.get(new_route) if new_route else None
            if rd and rd["blocked"]:
                reasons.append(f"route_blocked: {new_route}")
            found = next((s for s in self.shipments if s["id"] == shp), None)
            if not found:
                reasons.append("shipment_not_found")
            elif found["status"] != "delayed":
                reasons.append("not_delayed")
        else:
            reasons.append(f"unknown_type: {typ}")
        return {"ok": len(reasons) == 0, "reasons": reasons}

    # ---------- what-if simulation (MUST NOT mutate real env) ----------
    def simulate_action(self, action: Dict[str, Any]) -> Dict[str, Any]:
        """Return predicted outcome without mutating. Real calculated values."""
        v = self.validate_plan(action)
        if not v["ok"]:
            return {"feasible": False, "reasons": v["reasons"], "predicted_cost": action.get("cost", 0),
                    "predicted_time_days": action.get("time_days", 0), "predicted_carbon": action.get("carbon", 0),
                    "predicted_inventory": None, "predicted_shortage": None, "predicted_delay": None,
                    "predicted_service_level": None, "score": 999}
        # deep-copy state and apply on the copy
        inv = copy.deepcopy(self.inventory)
        ships = copy.deepcopy(self.shipments)
        typ = action.get("type")
        qty = action.get("qty", 0)
        sku = action.get("sku")
        new_ships = list(ships)
        if typ == "purchase":
            inv["DC-Chicago"][sku] = inv["DC-Chicago"].get(sku, 0) + qty
            new_ships.append({"id": "SIM", "sku": sku, "qty": qty, "status": "in_transit",
                              "eta_days": action.get("time_days", 2)})
        elif typ in ("transfer", "allocate"):
            src = action.get("from", "DC-Chicago")
            dst = action.get("to")
            inv[src][sku] -= qty
            inv[dst][sku] = inv[dst].get(sku, 0) + qty
        elif typ == "reroute":
            for s in new_ships:
                if s["id"] == action.get("shipment_id"):
                    s["route"] = action.get("new_route")
                    s["status"] = "rerouted"
                    s["eta_days"] = action.get("time_days", 2)
        # predicted service level on simulated inventory
        pred_sl: Dict[str, float] = {}
        total_short = 0
        for store, dem in self.demand.items():
            for s2, d in dem.items():
                have = inv.get(store, {}).get(s2, 0)
                pred_sl[f"{store}/{s2}"] = round(min(1, have / max(1, d)), 2)
                total_short += max(0, d - have)
        avg_sl = round(sum(pred_sl.values()) / max(1, len(pred_sl)), 3)
        # predicted delay: min ETA among relevant shipments
        pred_delay = action.get("time_days", 0)
        return {
            "feasible": True,
            "reasons": [],
            "predicted_inventory": inv,
            "predicted_shortage": total_short,
            "predicted_delay_days": pred_delay,
            "predicted_cost": action.get("cost", 0),
            "predicted_carbon": action.get("carbon", 0),
            "predicted_service_level": pred_sl,
            "predicted_avg_service": avg_sl,
        }

    # ---------- execution (mutates real env) ----------
    def execute_action(self, action: Dict[str, Any]) -> Dict[str, Any]:
        v = self.validate_plan(action)
        if not v["ok"]:
            return {"ok": False, "reason": "; ".join(v["reasons"])}
        typ = action.get("type")
        qty = action.get("qty", 0)
        sku = action.get("sku")
        cost = action.get("cost", 0)
        if typ == "purchase":
            vd = self.vendors.get(action.get("vendor"))
            # deterministic reliability draw (seeded) — reproducible
            if self.rng.random() > vd["reliability"]:
                return {"ok": False, "reason": "vendor_fulfillment_failed"}
            self.inventory["DC-Chicago"][sku] = self.inventory["DC-Chicago"].get(sku, 0) + qty
            vd["capacity"] -= qty
            self.budget_used += cost
            self.shipments.append({"id": f"SHP-{self.rng.randint(100, 999)}", "sku": sku, "qty": qty,
                                   "route": "direct-vendor", "status": "in_transit",
                                   "eta_days": vd["lead_days"], "vendor": action.get("vendor")})
            return {"ok": True, "new_inv": self.inventory["DC-Chicago"][sku]}
        elif typ == "transfer":
            src = action.get("from")
            dst = action.get("to")
            route = action.get("route")
            rd = self.routes.get(route)
            self.inventory[src][sku] -= qty
            self.inventory[dst][sku] = self.inventory[dst].get(sku, 0) + qty
            self.budget_used += cost
            if rd:
                rd["capacity"] -= qty
            self.shipments.append({"id": f"TRF-{self.rng.randint(100, 999)}", "sku": sku, "qty": qty,
                                   "route": route, "status": "in_transit",
                                   "eta_days": rd["time_days"] if rd else 1, "vendor": "internal"})
            return {"ok": True}
        elif typ == "reroute":
            shp = action.get("shipment_id")
            new_route = action.get("new_route")
            rd = self.routes.get(new_route)
            for s in self.shipments:
                if s["id"] == shp:
                    s["route"] = new_route
                    s["status"] = "rerouted"
                    s["eta_days"] = rd["time_days"] if rd else 2
                    self.budget_used += cost
                    return {"ok": True}
            return {"ok": False, "reason": "shipment_not_found"}
        elif typ == "allocate":
            dst = action.get("to")
            self.inventory["DC-Chicago"][sku] -= qty
            self.inventory[dst][sku] = self.inventory[dst].get(sku, 0) + qty
            self.budget_used += cost
            return {"ok": True}
        return {"ok": False, "reason": "unknown_type"}


env = Env()
