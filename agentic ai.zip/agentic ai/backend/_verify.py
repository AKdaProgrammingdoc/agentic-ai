import os, subprocess, sys, time
import httpx
proc = None
os.system("taskkill /F /PID 4372 2>nul")
time.sleep(1)
proc = subprocess.Popen(
    [sys.executable, "-m", "uvicorn", "main:app", "--host", "127.0.0.1", "--port", "8000"],
    cwd=os.path.dirname(os.path.abspath(__file__)),
    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL
)
time.sleep(4)
r = httpx.get("http://127.0.0.1:8000/", timeout=10)
print("home:" + str(r.status_code) + ":cache=" + str(r.headers.get("cache-control")))
print("has_fix:" + str("not file://" in r.text))
r = httpx.get("http://127.0.0.1:8000/api/state", timeout=10)
d = r.json()
e = d.get("env", {})
a = d.get("agent", {})
print("keys:" + str(sorted(e.keys())))
print("inv_ok:" + str(bool(e.get("inventory") and e.get("demand"))))
print("agent_state:" + str(a.get("state")))
print("SRV_PID:" + str(proc.pid))
