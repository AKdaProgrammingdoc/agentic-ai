from fastapi.testclient import TestClient
import main
c = TestClient(main.app)
c.post('/api/reset')
c.post('/api/scenario/shipment_delay')
r = c.post('/api/agent/run', json={'objective': 'fastest'})
print("status:", r.status_code)
print("state:", r.json()['agent']['state'])
print("objective:", r.json()['agent'].get('objective'))
