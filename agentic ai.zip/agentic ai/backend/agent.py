"""Autonomous recovery agent: explicit state machine + LLM tool-use loop + memory.

States: IDLE MONITORING DISRUPTION_DETECTED INVESTIGATING SIMULATING OPTIMIZING
        PLAN_READY AWAITING_APPROVAL EXECUTING VERIFYING REPLANNING RECOVERED FAILED
Timeline phases (UI pipeline): OBSERVE DETECT INVESTIGATE DECIDE OPTIMIZE ACT
        VERIFY ADAPT REPLAN SCENARIO (kept for existing frontend).
"""
import copy
import json
import time
from typing import Any, Dict, List, Optional

from simulation import env
import tools as T
import llm as LLM

STATES = ["IDLE", "MONITORING", "DISRUPTION_DETECTED", "INVESTIGATING", "SIMULATING",
          "OPTIMIZING", "PLAN_READY", "AWAITING_APPROVAL", "EXECUTING", "VERIFYING",
          "REPLANNING", "RECOVERED", "FAILED"]

SKU_WORDS = {"SKU-A:Electronics": "electronics", "SKU-B:Apparel": "clothes", "SKU-C:Grocery": "groceries"}
PLACE_WORDS = {"DC-Chicago": "Chicago warehouse", "Store-NYC": "NYC store", "Store-LA": "LA store"}
OBJECTIVE_WORDS = {"fastest": "speed", "lowest_cost": "cost", "lowest_carbon": "pollution", "balanced": "balanced"}
SCENARIO_WORDS = {"shipment_delay": "A shipment is delayed",
                  "vendor_failure": "A vendor stopped delivering",
                  "supplier_b_failure": "Supplier B stopped delivering",
                  "route_blockage": "A road is blocked",
                  "route_r2_blocked": "The Chicago–LA road is blocked",
                  "demand_spike": "Demand suddenly jumped",
                  "cascading": "Several problems hit at once",
                  "cascading_full": "Several problems hit at once"}


def plain_place(p):
    return PLACE_WORDS.get(p, p)


def plain_candidate(c):
    """One short human sentence per fix. No jargon, no JSON."""
    if not c:
        return "nothing"
    sku = SKU_WORDS.get(c.get("sku", ""), c.get("sku", ""))
    qty = c.get("qty", 0)
    t = c.get("type")
    if t == "purchase":
        s = f"Buy {qty} {sku} from {c.get('vendor')}"
    elif t == "transfer":
        s = f"Move {qty} {sku} from {plain_place(c.get('from'))} to {plain_place(c.get('to'))}"
    elif t == "allocate":
        s = f"Rush {qty} {sku} from the Chicago warehouse to the {plain_place(c.get('to'))}"
    elif t == "reroute":
        s = f"Re-send {c.get('shipment_id')} on {c.get('new_route')}"
    else:
        s = c.get("reason", t)
    return f"{s} (${c.get('cost', 0)}, {c.get('time_days', 0)}d)"


def plain_issue(i):
    t, target = i.get("type"), i.get("target")
    if t == "shipment_delay":
        return f"Shipment {target} is delayed"
    if t == "vendor_failure":
        return f"{target} can't deliver"
    if t == "route_blockage":
        return f"Road {target} is blocked"
    if t == "stockout_risk":
        return f"Low stock: {target}"
    if t == "demand_spike":
        return f"Sudden demand at {target}"
    return f"{t} at {target}"


class Agent:
    def __init__(self):
        self.reset()

    def reset(self):
        self.goal = "Maintain >=95% service level, minimize cost/time/carbon, stay within budget $50k"
        self.state = "IDLE"
        self.disruption: Optional[Dict[str, Any]] = None
        self.previous_plan = None
        self.current_plan = None
        self.selected = None
        self.candidates: List[Dict[str, Any]] = []
        self.actions: List[Dict[str, Any]] = []
        self.failures: List[Dict[str, Any]] = []
        self.verification: List[Dict[str, Any]] = []
        self.timeline: List[Dict[str, Any]] = []
        self.tool_activity: List[Dict[str, Any]] = []
        self.plan_history: List[Dict[str, Any]] = []  # PLAN n / status / reason
        self.invalid_reasons: Dict[str, str] = {}     # reason -> invalidation cause
        self.rejections: List[Dict[str, Any]] = []
        self.step = 0
        self.budget_limit = 50000
        self.objective = "balanced"
        self.require_approval = False  # False = auto-approve so EXISTING UI keeps working
        self.llm_used = False
        self.reasoning = ""
        self._plan_seq = 0

    # ---------- logging ----------
    def _log(self, phase, msg, detail=None):
        e = {"step": len(self.timeline) + 1, "phase": phase, "msg": msg,
             "ts": int(time.time() * 1000) % 100000, "detail": detail}
        self.timeline.append(e)
        return e

    def _tool(self, tool: str, args: Dict[str, Any]) -> Dict[str, Any]:
        ctx = {"candidates": self.candidates, "objective": self.objective,
               "plan_history": self.plan_history, "invalid_reasons": self.invalid_reasons,
               "expected": (self.selected or {}).get("simulation"),
               "last_action": self.actions[-1] if self.actions else None}
        try:
            res = T.dispatch(tool, args or {}, ctx)
            status = "SUCCESS" if res.get("ok") else "FAILED"
        except Exception as e:
            res = {"ok": False, "error": str(e)}
            status = "ERROR"
        entry = {"timestamp": int(time.time() * 1000) % 1000000, "state": self.state,
                 "tool": tool, "input": args or {},
                 "result": str(res)[:800], "status": status,
                 "reason": self.reasoning[:200] if self.reasoning else ""}
        self.tool_activity.append(entry)
        return res

    def _ctx_summary(self) -> str:
        return json.dumps({
            "objective": self.objective,
            "disruption": self.disruption,
            "plan_history": self.plan_history[-6:],
            "candidates": [{k: c.get(k) for k in ("type", "reason", "qty", "cost", "time_days", "carbon", "score", "feasible")} for c in self.candidates[:10]],
        })[:4000]

    # ---------- legacy-compatible observe/detect ----------
    def observe(self):
        self.state = "MONITORING"
        res = self._tool("observe_environment", {})
        snap = res.get("snapshot", env.snapshot())
        self._log("OBSERVE", "Checked every store, the warehouse and all shipments.")
        return snap

    def detect(self):
        issues = env.detect_issues()
        if issues:
            self.state = "DISRUPTION_DETECTED"
            self.disruption = issues[0]
            extra = f" (+{len(issues) - 1} more)" if len(issues) > 1 else ""
            self._log("DETECT", f"Problem found: {plain_issue(self.disruption)}.{extra}")
        else:
            self._log("DETECT", "All clear — everything is healthy.")
            if self.state not in ("RECOVERED", "AWAITING_APPROVAL"):
                self.state = "IDLE"
        return issues

    def monitor(self):
        """Autonomous monitoring inspection (GET /api/monitor)."""
        self.state = "MONITORING"
        res = self._tool("observe_environment", {})
        issues = res.get("issues", [])
        if issues:
            self.disruption = issues[0]
            self._log("DETECT", f"Watchdog spotted: {plain_issue(self.disruption)}.")
        if issues and self.selected:
            # check selected plan still valid
            v = env.validate_plan(self.selected)
            if not v["ok"]:
                cause = "; ".join(v["reasons"])
                self._invalidate_selected(cause)
        return {"issues": issues, "state": self.state, "disruption": self.disruption,
                "service_level": env.service_level()}

    def _invalidate_selected(self, cause: str):
        if self.selected:
            key = self.selected.get("reason", str(self.selected))
            self.invalid_reasons[key] = cause
            self._plan_seq += 1
            self.plan_history.append({"plan": self._plan_seq, "summary": self.selected.get("reason"),
                                      "type": self.selected.get("type"), "status": "INVALIDATED", "cause": cause})
            self._log("REPLAN", f"Noted: that fix can't work now ({cause}). It won't be tried again.")
            self.previous_plan = self.current_plan
            self.current_plan = None
            self.selected = None
            self.state = "REPLANNING"

    # ---------- candidate pipeline ----------
    def investigate(self):
        self.state = "INVESTIGATING"
        for t, a in [("get_inventory", {}), ("get_shipment_status", {}),
                     ("check_vendor_availability", {}), ("check_route_status", {}), ("get_demand", {})]:
            self._tool(t, a)
        res = self._tool("generate_recovery_candidates", {})
        self.candidates = res.get("candidates", [])
        self._log("INVESTIGATE", f"Looked at vendors, roads and stock — {len(self.candidates)} possible fixes.")
        return self.candidates

    def simulate(self):
        self.state = "SIMULATING"
        for c in self.candidates:
            r = self._tool("simulate_recovery_candidate", {"candidate": c})
            sim = r.get("simulation", {})
            if sim.get("feasible"):
                c["simulation"] = {k: sim.get(k) for k in
                                   ("predicted_avg_service", "predicted_shortage", "predicted_cost", "predicted_carbon", "predicted_delay_days")}
        self._log("INVESTIGATE", f"Tested all {len(self.candidates)} fixes on paper first — real stock untouched.")
        return self.candidates

    def optimize(self, objective: Optional[str] = None):
        self.state = "OPTIMIZING"
        if objective:
            self.objective = objective
        res = self._tool("optimize_recovery_options", {"objective": self.objective})
        ranked = res.get("ranked", [])
        feasible = [c for c in ranked if c.get("feasible")]
        infeasible = [c for c in ranked if not c.get("feasible")]
        self.candidates = ranked
        word = OBJECTIVE_WORDS.get(self.objective, self.objective)
        self._log("OPTIMIZE", f"Compared fixes by cost, speed and pollution — {len(feasible)} workable ({word} first).")
        if feasible:
            self.previous_plan = self.current_plan
            self.current_plan = feasible[0]
            self.selected = feasible[0]
            self.state = "PLAN_READY"
            self._log("DECIDE", f"Picked: {plain_candidate(self.selected)}.")
        else:
            self._log("DECIDE", "No workable fix — everything is blocked or over budget.")
            self.selected = None
            self.state = "FAILED"
        return feasible, infeasible

    # ---------- LLM-driven selection ----------
    def _llm_select(self) -> Optional[Dict[str, Any]]:
        """Let the LLM reason over tool outputs and pick a candidate.
        Returns selected candidate or None. Sets self.reasoning / self.llm_used."""
        if not LLM.is_configured():
            self.llm_used = False
            self.reasoning = "AI offline — backup planner used."
            self._log("DECIDE", self.reasoning)
            return next((c for c in self.candidates if c.get("feasible")), None)
        tools = T.tool_schemas_for_llm()
        convo: List[Dict[str, Any]] = [{
            "role": "user",
            "content": ("Objective: %s. Disruption: %s. Candidates+simulations: %s. "
                        "Plan history (avoid INVALIDATED): %s. Use tools to verify facts, "
                        "then reply final JSON {\"decision\": <exact candidate reason>, \"reasoning\": \"...\"}." % (
                            self.objective, json.dumps(self.disruption)[:800],
                            json.dumps(self.candidates)[:5000], json.dumps(self.plan_history[-6:])[:1500]))}]
        try:
            for _ in range(6):
                step = LLM.call_llm(convo, tools)
                if step["kind"] == "tool":
                    for call in step["calls"]:
                        res = self._tool(call["name"], call["args"])
                        convo.append({"role": "assistant", "content": f"called {call['name']}"})
                        convo.append({"role": "user", "content": f"tool {call['name']} result: {json.dumps(res)[:2500]}"})
                    continue
                content = step.get("content", "")
                try:
                    start = content.find("{")
                    data = json.loads(content[start:]) if start >= 0 else {}
                except Exception:
                    data = {}
                self.reasoning = str(data.get("reasoning") or content)[:1000]
                self.llm_used = True
                want = data.get("decision")
                if want:
                    for c in self.candidates:
                        if c.get("reason") == want and c.get("feasible"):
                            self._log("DECIDE", f"AI picked: {plain_candidate(c)}.")
                            return c
                # LLM gave reasoning but no exact match → take top feasible
                top = next((c for c in self.candidates if c.get("feasible")), None)
                if top:
                    self._log("DECIDE", f"AI weighed in — going with: {plain_candidate(top)}.")
                return top
            self.llm_used = True
            return next((c for c in self.candidates if c.get("feasible")), None)
        except RuntimeError as e:
            self.llm_used = False
            self.reasoning = "AI offline — backup planner used."
            self._log("DECIDE", self.reasoning)
            return next((c for c in self.candidates if c.get("feasible")), None)

    # ---------- approval / execution / verification ----------
    def request_approval(self):
        self.state = "AWAITING_APPROVAL"
        self._log("DECIDE", f"Waiting for your OK: {plain_candidate(self.selected)}.")
        return {"state": self.state, "selected": self.selected}

    def approve(self):
        if not self.selected:
            return {"ok": False, "reason": "no_selection"}
        v = self._tool("validate_recovery_plan", {"candidate": self.selected})
        if not (v.get("validation") or {}).get("ok"):
            self._invalidate_selected("; ".join((v.get("validation") or {}).get("reasons", ["invalid"])))
            return {"ok": False, "reason": "plan_invalid_on_approve", "replanned": self.replan()}
        res = self.act()
        ver = self.verify()
        if not ver.get("ok"):
            self.replan()
        return {"ok": res.get("ok", False), "result": res, "verify": ver, "state": self.state}

    def reject(self, reason: str = "human_rejected"):
        if not self.selected:
            return {"ok": False, "reason": "no_selection"}
        key = self.selected.get("reason", str(self.selected))
        self.invalid_reasons[key] = f"human_rejected: {reason}"
        self._plan_seq += 1
        self.plan_history.append({"plan": self._plan_seq, "summary": key, "type": self.selected.get("type"),
                                  "status": "REJECTED", "cause": reason})
        self.rejections.append({"plan": copy.deepcopy(self.selected), "reason": reason})
        self._log("REPLAN", f"You said no — noted it, trying the next option. Nothing was moved.")
        self.previous_plan = self.current_plan
        self.current_plan = None
        self.selected = None
        self.state = "REPLANNING"
        return {"ok": True, "replanned": self.replan()}

    def act(self):
        self.state = "EXECUTING"
        if not self.selected:
            self._log("ACT", "Nothing to do.")
            return {"ok": False, "reason": "no_selection"}
        v = env.validate_plan(self.selected)
        if not v["ok"]:
            self._invalidate_selected("; ".join(v["reasons"]))
            self._log("ACT", "Blocked at the last check — picking another fix.")
            return {"ok": False, "reason": v["reasons"]}
        before = env.snapshot()
        res = self._tool("execute_recovery_action", {"candidate": self.selected})
        after = res.get("after", env.snapshot())
        result = res.get("result", {})
        self.actions.append({"action": copy.deepcopy(self.selected), "result": result,
                             "before": before, "after": after})
        if result.get("ok"):
            self._log("ACT", f"Done: {plain_candidate(self.selected)}.")
        else:
            self.failures.append({"action": copy.deepcopy(self.selected), "error": result})
            self._log("ACT", f"That didn't work ({result.get('reason', 'unknown problem')}).")
        self.state = "VERIFYING"
        return result

    def verify(self):
        self.state = "VERIFYING"
        if not self.actions:
            self._log("VERIFY", "Nothing to check yet.")
            return {"ok": False}
        res = self._tool("verify_recovery", {})
        ok = bool(res.get("ok"))
        if not ok and self.actions and not self.actions[-1].get("result", {}).get("ok"):
            # execution itself failed — memorize so it is never retried this episode
            self._invalidate_selected(str(self.actions[-1]["result"].get("reason", "execution_failed")))
        self.verification.append({"ok": ok, "sl": res.get("service_level"), "changed": res.get("changed")})
        if ok:
            self._plan_seq += 1
            self.plan_history.append({"plan": self._plan_seq, "summary": (self.selected or {}).get("reason"),
                                      "type": (self.selected or {}).get("type"), "status": "EXECUTED_VERIFIED",
                                      "cause": f"avg_service={res.get('avg_service')}"})
            self._log("VERIFY", "Checked the shelves and deliveries — recovered.")
            self.state = "RECOVERED"
        else:
            self._log("VERIFY", "Check failed — the shelves still aren't right. Trying another fix.")
            self.state = "REPLANNING"
        return res

    def replan(self):
        self.state = "REPLANNING"
        self._log("ADAPT", "That fix is off the table — looking for the next best one.")
        issues = self.detect()
        if not issues:
            self.state = "RECOVERED"
            self._log("ADAPT", "Nothing wrong anymore — recovered.")
            return None
        self.investigate()
        self.simulate()
        feasible, _ = self.optimize()
        if not feasible:
            self.state = "FAILED"
            return None
        picked = self._llm_select()
        if picked:
            self.current_plan = picked
            self.selected = picked
            self.state = "PLAN_READY"
            self._log("REPLAN", f"Replanned → {picked['type']} {picked['reason']}")
            if self.require_approval:
                self.request_approval()
            else:
                self._log("REPLAN", f"New plan: {plain_candidate(picked)}.")
            return picked
        return None

    # ---------- main loop ----------
    def tick(self, objective: Optional[str] = None):
        self.step += 1
        if objective:
            self.objective = objective
        self.observe()
        issues = self.detect()
        if not issues:
            if self.state != "RECOVERED":
                self.state = "IDLE"
            return {"state": self.state, "msg": "healthy"}
        # ongoing episode: check selected plan still valid before acting
        if self.selected:
            v = env.validate_plan(self.selected)
            if not v["ok"]:
                self._invalidate_selected("; ".join(v["reasons"]))
                picked = self.replan()
                if picked and not self.require_approval:
                    res = self.act()
                    ver = self.verify()
                    if not ver.get("ok") and ver.get("need_replan"):
                        r2 = self.replan()
                        if r2 and not self.require_approval:
                            res2 = self.act()
                            ver2 = self.verify()
                            return {"state": self.state, "result": res2, "verify": ver2}
                    return {"state": self.state, "result": res, "verify": ver}
                return {"state": self.state, "msg": "replanned_awaiting_approval" if self.require_approval else "replanned"}
        self.investigate()
        self.simulate()
        self.optimize()
        if not self.selected:
            return {"state": self.state, "msg": "no feasible"}
        picked = self._llm_select()
        if picked:
            self.current_plan = picked
            self.selected = picked
        self.request_approval()
        if self.require_approval:
            return {"state": self.state, "msg": "awaiting_approval", "selected": self.selected}
        res = self.act()
        ver = self.verify()
        if not ver.get("ok"):
            r2 = self.replan()
            if r2 and not self.require_approval:
                res2 = self.act()
                ver2 = self.verify()
                return {"state": self.state, "result": res2, "verify": ver2}
        return {"state": self.state, "result": res, "verify": ver}


agent = Agent()
