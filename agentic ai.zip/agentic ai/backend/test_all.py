import os, sys
sys.path.insert(0, os.path.dirname(__file__))

from fastapi.testclient import TestClient
from main import app

c = TestClient(app)

# Test 1: Health
r = c.get('/api/health')
print("1. Health:", r.json())

# Test 2: Reset
r = c.post('/api/reset')
print("2. Reset - state:", r.json()['agent']['state'])

# Test 3: Get initial state
r = c.get('/api/state')
d = r.json()
print("3. Initial state:", d['agent']['state'], "| Objective:", d['agent']['objective'], "| LLM used:", d['agent'].get('llm_used'))

# Test 4: Apply scenario
r = c.post('/api/scenario/shipment_delay')
d = r.json()
print("4. Scenario applied:", "Disruption:", d['agent']['disruption'] is not None)

# Test 5: Run agent
r = c.post('/api/agent/run', json={'objective': 'balanced'})
d = r.json()
print("5. Agent run - State:", d['agent']['state'], "| LLM used:", d['agent'].get('llm_used'), "| Reasoning:", d['agent'].get('reasoning', '')[:40])
print("   Timeline:", [t['phase'] for t in d['agent']['timeline'][-5:]])
print("   Actions:", len(d['agent']['actions']), "| Budget used:", d['env']['budget_used'])

# Test 6: LLM status
r = c.get('/api/llm')
d = r.json()
print("6. LLM status:", d['configured'])

# Test 7: History
r = c.get('/api/history')
d = r.json()
print("7. History - Timeline entries:", len(d['timeline']), "| Tool activity:", len(d['tool_activity']))

# Test 8: Reset again
r = c.post('/api/reset')
print("8. Reset done - state:", r.json()['agent']['state'])

print("\nAll endpoint tests passed!")
