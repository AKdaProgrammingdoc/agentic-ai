import httpx
base = "http://127.0.0.1:8000"
r = httpx.get(base + "/", timeout=10)
print("home:" + str(r.status_code) + ":len=" + str(len(r.text)))
print("has_runAgent:" + str("runAgent" in r.text))
print("has_currentObjective:" + str("currentObjective" in r.text))
r = httpx.get(base + "/api/state", timeout=10)
d = r.json()
print("state_keys:" + str(sorted(d.keys())))
print("agent_state:" + str(d["agent"].get("state")))
print("timeline_n:" + str(len(d["agent"].get("timeline", []))))
r = httpx.get(base + "/api/llm", timeout=10)
print("llm:" + str(r.json()))
