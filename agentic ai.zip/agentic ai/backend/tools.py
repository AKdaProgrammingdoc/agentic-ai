"""Real agent tools. Every tool executes deterministic backend logic
and returns structured results. The agent records each call in history."""
import copy
from typing import Any, Dict, List

from simulation import env


def _shortage_findings() -> List[Dict[str, Any]]:
    findings = []
    for store in env.demand:
        for sku, d in env.demand[store].items():
            have = env.inventory.get(store, {}).get(sku, 0)
            dc_have = env.inventory.get("DC-Chicago", {}).get(sku, 0)
            short = max(0, d - have)
            if short > 0:
                findings.append({"store": store, "sku": sku, "shortage": short,
                                 "dc_have": dc_have, "demand": d, "have": have})
    return findings


TOOLS: Dict[str, Dict[str, Any]] = {
    "observe_environment": {"desc": "Full snapshot of inventory, shipments, vendors, routes, demand, budget, disruptions"},
    "get_inventory": {"desc": "Current inventory per location/SKU"},
    "get_shipment_status": {"desc": "Status of one or all shipments. Input: {shipment_id?}"},
    "check_vendor_availability": {"desc": "Vendor capacity/status. Input: {vendor?}"},
    "check_route_status": {"desc": "Route blocked/capacity. Input: {route?}"},
    "get_demand": {"desc": "Demand per store/SKU"},
    "generate_recovery_candidates": {"desc": "Generate feasible recovery candidates from shortages"},
    "simulate_recovery_candidate": {"desc": "What-if simulate a candidate (no mutation). Input: {candidate}"},
    "optimize_recovery_options": {"desc": "Score+rank candidates. Input: {candidates?, objective?}"},
    "validate_recovery_plan": {"desc": "Pre-execution validation. Input: {candidate}"},
    "execute_recovery_action": {"desc": "Execute approved plan (mutates env). Input: {candidate}"},
    "verify_recovery": {"desc": "Post-execution verification vs expected"},
    "get_plan_history": {"desc": "Prior plans + invalidation reasons for this episode"},
}


def tool_schemas_for_llm() -> List[Dict[str, Any]]:
    return [{"name": n, "description": v["desc"]} for n, v in TOOLS.items()]


def dispatch(tool: str, args: Dict[str, Any], ctx: Dict[str, Any]) -> Dict[str, Any]:
    """Execute tool against the real env. ctx holds agent memory (objective, invalid, plans)."""
    args = args or {}
    if tool == "observe_environment":
        snap = env.snapshot()
        return {"ok": True, "snapshot": snap, "service_level": env.service_level(),
                "issues": env.detect_issues()}
    if tool == "get_inventory":
        return {"ok": True, "inventory": copy.deepcopy(env.inventory)}
    if tool == "get_shipment_status":
        sid = args.get("shipment_id")
        ships = env.shipments if not sid else [s for s in env.shipments if s["id"] == sid]
        return {"ok": True, "shipments": copy.deepcopy(ships)}
    if tool == "check_vendor_availability":
        v = args.get("vendor")
        if v:
            return {"ok": True, "vendor": v, "data": copy.deepcopy(env.vendors.get(v))}
        return {"ok": True, "vendors": copy.deepcopy(env.vendors)}
    if tool == "check_route_status":
        r = args.get("route")
        if r:
            return {"ok": True, "route": r, "data": copy.deepcopy(env.routes.get(r))}
        return {"ok": True, "routes": copy.deepcopy(env.routes)}
    if tool == "get_demand":
        return {"ok": True, "demand": copy.deepcopy(env.demand)}
    if tool == "generate_recovery_candidates":
        return {"ok": True, "candidates": _generate(args.get("shortages"))}
    if tool == "simulate_recovery_candidate":
        cand = args.get("candidate", {})
        sim = env.simulate_action(cand)
        return {"ok": True, "simulation": sim}
    if tool == "optimize_recovery_options":
        cands = args.get("candidates") or ctx.get("candidates") or []
        objective = args.get("objective") or ctx.get("objective", "balanced")
        ranked = _optimize(cands, objective, ctx)
        return {"ok": True, "objective": objective, "ranked": ranked}
    if tool == "validate_recovery_plan":
        cand = args.get("candidate", {})
        return {"ok": True, "validation": env.validate_plan(cand)}
    if tool == "execute_recovery_action":
        cand = args.get("candidate", {})
        before = env.snapshot()
        res = env.execute_action(cand)
        after = env.snapshot()
        return {"ok": res.get("ok", False), "result": res, "before": before, "after": after}
    if tool == "verify_recovery":
        expected = args.get("expected") or ctx.get("expected")
        last = ctx.get("last_action")
        sl = env.service_level()
        if not last:
            return {"ok": False, "reason": "nothing_to_verify", "service_level": sl}
        res = last.get("result", {})
        if not res.get("ok"):
            return {"ok": False, "reason": res.get("reason"), "service_level": sl, "need_replan": True}
        before, after = last.get("before", {}), last.get("after", {})
        changed = before.get("inventory") != after.get("inventory") or before.get("shipments") != after.get("shipments")
        exp_sl = (expected or {}).get("predicted_avg_service")
        cur_avg = round(sum(sl.values()) / max(1, len(sl)), 3)
        improved = exp_sl is None or cur_avg >= min(exp_sl, 0.85) or changed
        ok = bool(changed and improved)
        return {"ok": ok, "changed": changed, "service_level": sl, "avg_service": cur_avg,
                "expected_avg": exp_sl, "need_replan": not ok}
    if tool == "get_plan_history":
        return {"ok": True, "plans": copy.deepcopy(ctx.get("plan_history", [])),
                "invalid": sorted(list(ctx.get("invalid_reasons", {}).keys()))}
    return {"ok": False, "error": f"unknown_tool: {tool}"}


def _generate(shortages=None) -> List[Dict[str, Any]]:
    findings = shortages or _shortage_findings()
    cand: List[Dict[str, Any]] = []
    for f in findings:
        sku, short, store = f["sku"], f["shortage"], f["store"]
        for vname, vd in env.vendors.items():
            if vd["sku"] == sku and vd["active"] and vd["capacity"] > 0:
                qty = min(short, vd["capacity"])
                cost = qty * vd["cost"] + 50
                cand.append({"type": "purchase", "sku": sku, "qty": qty, "vendor": vname,
                             "cost": cost, "time_days": vd["lead_days"],
                             "carbon": round(vd["carbon"] * qty / 100, 1), "to": store,
                             "reason": f"Buy {qty} {sku} from {vname}"})
        dc_have = env.inventory.get("DC-Chicago", {}).get(sku, 0)
        if dc_have > 0:
            for rname, rd in env.routes.items():
                if rd["from"] == "DC-Chicago" and rd["to"] == store and not rd["blocked"]:
                    qty = min(short, dc_have, rd["capacity"])
                    if qty > 0:
                        cand.append({"type": "transfer", "sku": sku, "qty": qty, "from": "DC-Chicago",
                                     "to": store, "route": rname, "cost": rd["cost"],
                                     "time_days": rd["time_days"], "carbon": rd["carbon"],
                                     "reason": f"Move {qty} {sku} from the Chicago warehouse to {store} via {rname}"})
        if dc_have > 0:
            qty = min(short, dc_have)
            cand.append({"type": "allocate", "sku": sku, "qty": qty, "from": "DC-Chicago",
                         "to": store, "cost": 20, "time_days": 1, "carbon": 10,
                         "reason": f"Rush {qty} {sku} from the Chicago warehouse to {store}"})
        for s in env.shipments:
            if s["status"] == "delayed" and s["sku"] == sku:
                for rname, rd in env.routes.items():
                    if not rd["blocked"] and rd["capacity"] >= s["qty"]:
                        cand.append({"type": "reroute", "sku": sku, "qty": s["qty"],
                                     "shipment_id": s["id"], "new_route": rname,
                                     "cost": max(0, rd["cost"] - 50), "time_days": rd["time_days"],
                                     "carbon": rd["carbon"], "reason": f"Re-send {s['id']} on {rname}"})
    for f in findings:
        sku, store, short = f["sku"], f["store"], f["shortage"]
        other = "Store-LA" if store == "Store-NYC" else "Store-NYC"
        other_have = env.inventory.get(other, {}).get(sku, 0)
        other_dem = env.demand.get(other, {}).get(sku, 0)
        surplus = other_have - other_dem
        if surplus > 20:
            rd = env.routes.get("R3:NYC-LA")
            if rd and not rd["blocked"]:
                qty = min(short, surplus)
                cand.append({"type": "transfer", "sku": sku, "qty": qty, "from": other,
                             "to": store, "route": "R3:NYC-LA", "cost": rd["cost"],
                             "time_days": rd["time_days"], "carbon": rd["carbon"] + 5,
                             "reason": f"Move {qty} {sku} from {other} to {store} (store to store)"})
    return cand


def _score(c: Dict[str, Any], objective: str) -> float:
    cost_n = c.get("cost", 0) / 1000.0
    time_n = c.get("time_days", 0) / 5.0
    co2_n = c.get("carbon", 0) / 100.0
    qty_pen = 0 if c.get("qty", 0) >= 50 else 0.5
    if objective == "fastest":
        w = (0.2, 0.6, 0.1, 0.1)
    elif objective == "lowest_cost":
        w = (0.6, 0.2, 0.1, 0.1)
    elif objective == "lowest_carbon":
        w = (0.2, 0.2, 0.5, 0.1)
    else:
        w = (0.4, 0.3, 0.2, 0.1)
    return round(cost_n * w[0] + time_n * w[1] + co2_n * w[2] + qty_pen * w[3], 3)


def _optimize(cands: List[Dict[str, Any]], objective: str, ctx: Dict[str, Any]) -> List[Dict[str, Any]]:
    invalid = ctx.get("invalid_reasons", {})
    out = []
    for c in cands:
        key = c.get("reason")
        if key in invalid:
            c2 = dict(c, feasible=False, score=999,
                      infeasible_reason=f"previously invalidated: {invalid[key]}")
            out.append(c2)
            continue
        v = env.validate_plan(c)
        sim = env.simulate_action(c)
        if not v["ok"] or not sim.get("feasible"):
            c2 = dict(c, feasible=False, score=999,
                      infeasible_reason="; ".join(v.get("reasons", []) or sim.get("reasons", [])))
            out.append(c2)
            continue
        c2 = dict(c, feasible=True, score=_score(c, objective), simulation={
            "predicted_avg_service": sim.get("predicted_avg_service"),
            "predicted_shortage": sim.get("predicted_shortage"),
            "predicted_cost": sim.get("predicted_cost"),
            "predicted_carbon": sim.get("predicted_carbon"),
            "predicted_delay_days": sim.get("predicted_delay_days")})
        out.append(c2)
    out.sort(key=lambda x: (x["score"] if x.get("feasible") else 9999))
    return out
