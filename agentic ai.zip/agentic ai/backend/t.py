import httpx

r = httpx.post('http://127.0.0.1:8000/api/agent/run', json={'objective': 'balanced'})
d = r.json()
print("State:", d['agent']['state'])
print("LLM used:", d['agent'].get('llm_used'))
print("Reasoning:", d['agent'].get('reasoning', '')[:60])
print("Timeline:", [t['phase'] for t in d['agent']['timeline'][-4:]])
r2 = httpx.get('http://127.0.0.1:8000/api/llm')
print("LLM config:", r2.json())
