import httpx, json

r = httpx.post('http://127.0.0.1:8000/api/agent/run', json={'objective': 'balanced'})
print('Status:', r.status_code)
d = r.json()
print('Agent state:', d['agent']['state'])
print('Timeline last 5:', [(t['phase'], t['msg'][:60]) for t in d['agent']['timeline'][-5:]])
print('Disruption:', d['agent']['disruption'])
print('Selected:', d['agent']['selected'])
print('Candidates:', len(d['agent']['candidates']))
print('LLM used:', d['agent']['llm_used'])
print('Actions:', len(d['agent']['actions']))
print('Service level avg:', sum(d['service_level'].values())/len(d['service_level']))
