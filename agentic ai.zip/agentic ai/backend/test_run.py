from fastapi.testclient import TestClient
from main import app

c = TestClient(app)
r = c.post('/api/agent/run', json={'objective': 'balanced'})
d = r.json()
print('Status:', r.status_code)
print('State:', d['agent']['state'])
print('Timeline last 5:', [(t['phase'], t['msg'][:50]) for t in d['agent']['timeline'][-5:]])
print('Disruption:', d['agent']['disruption'] is not None)
print('LLM used:', d['agent']['llm_used'])
print('Selected:', d['agent']['selected'])
print('Candidates:', len(d['agent']['candidates']))
print('Actions:', len(d['agent']['actions']))
print('Service level avg:', sum(d['service_level'].values()) / len(d['service_level']))
print('Budget used:', d['env']['budget_used'], '/', d['env']['budget'])
