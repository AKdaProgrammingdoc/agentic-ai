import os, sys, httpx
sys.path.insert(0, os.path.dirname(__file__))

# Test server is running
r = httpx.get('http://127.0.0.1:8000/api/health')
print("Health:", r.json())

# Test frontend
r = httpx.get('http://127.0.0.1:8000/')
print("Frontend status:", r.status_code)
print("Has setObjective:", "setObjective" in r.text)
print("Has runAgent:", "runAgent" in r.text)

# Test agent run
r = httpx.post('http://127.0.0.1:8000/api/agent/run', json={'objective': 'balanced'})
d = r.json()
print("Agent run - State:", d['agent']['state'], "| LLM used:", d['agent'].get('llm_used'), "| Budget:", d['env']['budget_used'])

# Test reset
r = httpx.post('http://127.0.0.1:8000/api/reset')
print("Reset - State:", r.json()['agent']['state'])

# Test LLM status
r = httpx.get('http://127.0.0.1:8000/api/llm')
d = r.json()
print("LLM configured:", d['configured'], "| Model:", d['model'])

# Test objective endpoint
r = httpx.post('http://127.0.0.1:8000/api/agent/objective', json={'objective': 'fastest'})
print("Objective set:", r.json()['objective'])

print("\nAll systems operational!")
