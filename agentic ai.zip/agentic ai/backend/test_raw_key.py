import os, sys, json, urllib.request
sys.path.insert(0, os.path.dirname(__file__))

from dotenv import load_dotenv
load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

key = os.getenv("LLM_API_KEY")
url = "https://api.groq.com/openai/v1/chat/completions"

payload = {
    "model": "llama-3.3-70b-versatile",
    "messages": [{"role": "user", "content": "Hello"}],
    "temperature": 0.2
}

req = urllib.request.Request(
    url,
    data=json.dumps(payload).encode(),
    headers={
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
        "X-Stainless-Arch": "x86_64",
        "X-Stainless-Lang": "python",
        "X-Stainless-OS": "Windows",
        "X-Stainless-Interface": "python-httpx"
    }
)

try:
    with urllib.request.urlopen(req, timeout=10) as r:
        data = json.loads(r.read().decode())
        print("SUCCESS:", json.dumps(data)[:200])
except urllib.error.HTTPError as e:
    body = e.read().decode()
    print(f"HTTP {e.code}: {body[:300]}")
except Exception as e:
    print("Error:", type(e).__name__, str(e)[:200])
