
let auto=null, last=null
async function api(p,o){try{let r=await fetch(p,{method:o?.method||'GET',headers:{'Content-Type':'application/json'},body:o?.body});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}catch(e){console.error('API error:',p,e);alert('API error: '+e.message+' — open via http://127.0.0.1:8000, not file://');return null}}
async function refresh(){let s=await api('/api/state');if(s)render(s)}
function render(s){
 last=s; document.getElementById('goal').textContent=s.agent.goal
 let inv=s.env.inventory, dem=s.env.demand
 document.getElementById('inv').innerHTML=Object.keys(inv).map(loc=>`<tr><td>${loc}</td><td>${inv[loc]['SKU-A:Electronics']}</td><td>${inv[loc]['SKU-B:Apparel']}</td><td>${inv[loc]['SKU-C:Grocery']}</td><td class="mono">${dem[loc]?dem[loc]['SKU-A:Electronics']+'/'+dem[loc]['SKU-B:Apparel']+'/'+dem[loc]['SKU-C:Grocery']:'\u2014'}</td></tr>`).join('')
 let sl=s.service_level, vals=Object.values(sl), avg=(vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(2)
 document.getElementById('sl').textContent=avg; document.getElementById('sl').style.color=avg>=0.9?'#0B5C2E':'#8C2438'
 let byStore={};Object.entries(sl).forEach(([k,v])=>{let p=k.split('/');let st=p[0].replace('Store-','');(byStore[st]=byStore[st]||[]).push(p[1].split(':')[0].split('-')[1]+' '+v)});document.getElementById('slDetail').innerHTML=Object.entries(byStore).map(([st,arr])=>st+' \u2014 '+arr.join(' \u00b7 ')).join('<br>')
 document.getElementById('budget').textContent='$'+s.env.budget_used+' / $'+s.env.budget
 document.getElementById('budgetD').textContent=''
 document.getElementById('astate').className='status'; document.getElementById('astate').style.color=s.agent.state=='RECOVERED'?'#0B5C2E':s.agent.state=='FAILED'?'#8C2438':'#5A5A55'
 let dotColor=s.agent.state=='RECOVERED'?'#0B5C2E':s.agent.state=='FAILED'?'#8C2438':'#5A5A55'
 document.getElementById('astate').innerHTML=`<span class="dot" style="background:${dotColor}"></span>${s.agent.state}`
 let stages=["OBSERVE","DETECT","INVESTIGATE","DECIDE","OPTIMIZE","ACT","VERIFY","ADAPT","REPLAN"]
 let tl=(s.agent.timeline||[]), lastPhase=tl.length?tl[tl.length-1].phase:""
 if(lastPhase=="OPTIMIZED") lastPhase="OPTIMIZE"
 if(lastPhase=="DECIDED") lastPhase="DECIDE"
 let curIdx=stages.indexOf(lastPhase)
 document.getElementById('pipeline').innerHTML=`<nav class="menu menu--ariel"><ul class="menu__list">${stages.map((st,i)=>`<li class="menu__item ${i==curIdx?'menu__item--current':''} ${curIdx>=0&&i>curIdx?'menu__item--future':''}"><a class="menu__link">${st.charAt(0)+st.slice(1).toLowerCase()}</a></li>`).join('')}</ul></nav>`
 document.getElementById('adisr').textContent=s.agent.disruption? s.agent.disruption.type+' @ '+s.agent.disruption.target : ''
 let net=document.getElementById('network')
 net.innerHTML=`<div class="node">\uD83D\uDEE0\uFE0F Vendors<br><small class="mono">${Object.keys(s.env.vendors).join('<br>')}</small></div>
 <div class="node">\uD83D\uDCD0 DC-Chicago<br><b>${s.env.inventory['DC-Chicago']['SKU-A:Electronics']}/${s.env.inventory['DC-Chicago']['SKU-B:Apparel']}/${s.env.inventory['DC-Chicago']['SKU-C:Grocery']}</b></div>
 <div class="node">\uD83C\uDFE7 Store-NYC<br><b>${s.env.inventory['Store-NYC']['SKU-A:Electronics']}/${s.env.inventory['Store-NYC']['SKU-B:Apparel']}/${s.env.inventory['Store-NYC']['SKU-C:Grocery']}</b></div>
 <div class="node">\uD83C\uDFE7 Store-LA<br><b>${s.env.inventory['Store-LA']['SKU-A:Electronics']}/${s.env.inventory['Store-LA']['SKU-B:Apparel']}/${s.env.inventory['Store-LA']['SKU-C:Grocery']}</b></div>`
 document.getElementById('routes').innerHTML=Object.entries(s.env.routes).map(([k,v])=>`<span class="route ${v.blocked?'blocked':'ok'}">${k} ${v.blocked?'\u26D4BLOCKED':'\u2714'} $${v.cost} \u00b7 ${v.time_days}d \u00b7 cap ${v.capacity}</span>`).join(' ')
 document.getElementById('vendors').innerHTML=Object.entries(s.env.vendors).map(([k,v])=>`<tr><td>${k}</td><td>${v.sku.split(':')[0]}</td><td>${v.capacity}</td><td>$${v.cost}</td><td><span class="chip ${v.active?'ok':'bad'}">${v.active?'active':'DOWN'}</span></td></tr>`).join('')
 document.getElementById('ships').innerHTML=s.env.shipments.map(sh=>`<tr><td>${sh.id}</td><td>${sh.sku.split(':')[0]} x${sh.qty}</td><td>${sh.route}</td><td><span class="chip ${sh.status=='delayed'?'bad':sh.status=='rerouted'?'warn':'ok'}">${sh.status}</span> ${sh.eta_days}d</td></tr>`).join('')
 let d=s.agent.disruption, ds=document.getElementById('disr')
 if(s.env.disruptions.length) ds.innerHTML=s.env.disruptions.map(x=>`<div class="chip bad">${x.type}: ${x.desc}</div>`).join(' ')
 else if(d) ds.innerHTML=`<div class="chip warn">${d.type} @ ${d.target}</div>`
 else ds.innerHTML='<span class="chip ok">No disruption \u2014 healthy</span>'
 let sel=s.agent.selected||s.agent.current_plan
 document.getElementById('selected').innerHTML= sel? `<div class="cand sel"><b>&#9654; Selected: ${sel.type.toUpperCase()}</b> \u2014 ${sel.reason}<br><span class="mono">qty ${sel.qty} cost $${sel.cost} time ${sel.time_days}d carbon ${sel.carbon} score ${sel.score} ${sel.feasible===false?'\u26D4 infeasible':''}</span></div>` : '<div class="mono">No selection yet \u2014 run agent</div>'
 let cands=s.agent.candidates||[]
 document.getElementById('cands').innerHTML= cands.length? cands.slice(0,8).map(c=>{let isSel=sel&&c.reason==sel.reason;return `<div class="cand ${isSel?'sel':''}"><b>${c.type}</b> ${c.reason} ${isSel?'<span class="sel-badge">SELECTED</span>':''} <span class="chip ${c.feasible===false?'bad':'ok'}">${c.feasible===false?'rejected':'feasible'}</span><br><span class="mono">$${c.cost} ${c.time_days}d CO2 ${c.carbon} score ${c.score||'-'}</span></div>`}).join('') : '<span class="mono">No candidates \u2014 waiting for detection</span>'
 document.getElementById('timeline').innerHTML=(s.agent.timeline||[]).slice(-20).map(t=>`<div class="step ${t.phase}"><span class="badge">${t.phase}</span> <small class="mono">#${t.step}</small> ${t.msg}${t.detail?'<pre class="detail">'+JSON.stringify(t.detail,null,2)+'</pre>':''}</div>`).join('') || '<small>Empty</small>'
 let acts=s.agent.actions
 if(acts && acts.length){let a=acts[acts.length-1];let L=[];Object.keys(a.before.inventory).forEach(loc=>{Object.keys(a.before.inventory[loc]).forEach(sku=>{let b=a.before.inventory[loc][sku],c=(a.after.inventory[loc]||{})[sku];if(b!==c)L.push(loc+': '+sku.split(':')[1]+' '+b+' \u2192 '+c)})});document.getElementById('beforeAfter').textContent=(L.length?('Stock moved:\n'+L.join('\n')):'No stock change')+'\nResult: '+((a.result&&a.result.ok)?'worked':'did not work')}
 else document.getElementById('beforeAfter').textContent='No actions yet'
 let obj=(s.agent.objective||'balanced')
 let objLabel={'fastest':'Speed','lowest_cost':'Low Cost','lowest_carbon':'Low Pollution','balanced':'Balanced'}[obj]||obj
 document.getElementById('obj').textContent=objLabel; document.getElementById('objD').textContent=''
 document.getElementById('plans').textContent=(s.agent.timeline||[]).filter(t=>['DECIDE','REPLAN','OPTIMIZE'].includes(t.phase)).length
 document.getElementById('plansD').textContent=''
 document.getElementById('costSpent').textContent='$'+(s.env.budget_used||0); document.getElementById('costD').textContent=''
 ['F','C','P','B'].forEach(id=>{let el=document.getElementById('btn'+id);if(el)el.style.borderColor=(el.id==('btn'+{F:'fastest',C:'lowest_cost',P:'lowest_carbon',B:'balanced'}[id])&&obj=={F:'fastest',C:'lowest_cost',P:'lowest_carbon',B:'balanced'}[id])?'var(--red)':'var(--border)'})
}
async function scenario(n){await api('/api/scenario/'+n,{method:'POST'});await refresh()}
let currentObjective = 'balanced'
async function api(p,o){try{let r=await fetch(p,{method:o?.method||'GET',headers:{'Content-Type':'application/json'},body:o?.body});if(!r.ok)throw new Error('HTTP '+r.status);return await r.json()}catch(e){console.error('API error:',p,e);alert('API error: '+e.message);return null}}
async function refresh(){let s=await api('/api/state');if(s)render(s)}
function render(s){
 last=s; document.getElementById('goal').textContent=s.agent.goal
 let inv=s.env.inventory, dem=s.env.demand
 document.getElementById('inv').innerHTML=Object.keys(inv).map(loc=>`<tr><td>${loc}</td><td>${inv[loc]['SKU-A:Electronics']}</td><td>${inv[loc]['SKU-B:Apparel']}</td><td>${inv[loc]['SKU-C:Grocery']}</td><td class="mono">${dem[loc]?dem[loc]['SKU-A:Electronics']+'/'+dem[loc]['SKU-B:Apparel']+'/'+dem[loc]['SKU-C:Grocery']:'\u2014'}</td></tr>`).join('')
 let sl=s.service_level, vals=Object.values(sl), avg=(vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(2)
 document.getElementById('sl').textContent=avg; document.getElementById('sl').style.color=avg>=0.9?'#0B5C2E':'#8C2438'
 let byStore={};Object.entries(sl).forEach(([k,v])=>{let p=k.split('/');let st=p[0].replace('Store-','');(byStore[st]=byStore[st]||[]).push(p[1].split(':')[0].split('-')[1]+' '+v)});document.getElementById('slDetail').innerHTML=Object.entries(byStore).map(([st,arr])=>st+' \u2014 '+arr.join(' \u00b7 ')).join('<br>')
 document.getElementById('budget').textContent='$'+s.env.budget_used+' / $'+s.env.budget
 document.getElementById('budgetD').textContent=''
 document.getElementById('astate').className='status'; document.getElementById('astate').style.color=s.agent.state=='RECOVERED'?'#0B5C2E':s.agent.state=='FAILED'?'#8C2438':'#5A5A55'
 let dotColor=s.agent.state=='RECOVERED'?'#0B5C2E':s.agent.state=='FAILED'?'#8C2438':'#5A5A55'
 document.getElementById('astate').innerHTML=`<span class="dot" style="background:${dotColor}"></span>${s.agent.state}`
 let stages=["OBSERVE","DETECT","INVESTIGATE","DECIDE","OPTIMIZE","ACT","VERIFY","ADAPT","REPLAN"]
 let tl=(s.agent.timeline||[]), lastPhase=tl.length?tl[tl.length-1].phase:""
 if(lastPhase=="OPTIMIZED") lastPhase="OPTIMIZE"
 if(lastPhase=="DECIDED") lastPhase="DECIDE"
 let curIdx=stages.indexOf(lastPhase)
 document.getElementById('pipeline').innerHTML=`<nav class="menu menu--ariel"><ul class="menu__list">${stages.map((st,i)=>`<li class="menu__item ${i==curIdx?'menu__item--current':''} ${curIdx>=0&&i>curIdx?'menu__item--future':''}"><a class="menu__link">${st.charAt(0)+st.slice(1).toLowerCase()}</a></li>`).join('')}</ul></nav>`
 document.getElementById('adisr').textContent=s.agent.disruption? s.agent.disruption.type+' @ '+s.agent.disruption.target : ''
 let net=document.getElementById('network')
 net.innerHTML=`<div class="node">\uD83D\uDEE0\uFE0F Vendors<br><small class="mono">${Object.keys(s.env.vendors).join('<br>')}</small></div>
 <div class="node">\uD83D\uDCD0 DC-Chicago<br><b>${s.env.inventory['DC-Chicago']['SKU-A:Electronics']}/${s.env.inventory['DC-Chicago']['SKU-B:Apparel']}/${s.env.inventory['DC-Chicago']['SKU-C:Grocery']}</b></div>
 <div class="node">\uD83C\uDFE7 Store-NYC<br><b>${s.env.inventory['Store-NYC']['SKU-A:Electronics']}/${s.env.inventory['Store-NYC']['SKU-B:Apparel']}/${s.env.inventory['Store-NYC']['SKU-C:Grocery']}</b></div>
 <div class="node">\uD83C\uDFE7 Store-LA<br><b>${s.env.inventory['Store-LA']['SKU-A:Electronics']}/${s.env.inventory['Store-LA']['SKU-B:Apparel']}/${s.env.inventory['Store-LA']['SKU-C:Grocery']}</b></div>`
 document.getElementById('routes').innerHTML=Object.entries(s.env.routes).map(([k,v])=>`<span class="route ${v.blocked?'blocked':'ok'}">${k} ${v.blocked?'\u26D4BLOCKED':'\u2714'} $${v.cost} \u00b7 ${v.time_days}d \u00b7 cap ${v.capacity}</span>`).join(' ')
 document.getElementById('vendors').innerHTML=Object.entries(s.env.vendors).map(([k,v])=>`<tr><td>${k}</td><td>${v.sku.split(':')[0]}</td><td>${v.capacity}</td><td>$${v.cost}</td><td><span class="chip ${v.active?'ok':'bad'}">${v.active?'active':'DOWN'}</span></td></tr>`).join('')
 document.getElementById('ships').innerHTML=s.env.shipments.map(sh=>`<tr><td>${sh.id}</td><td>${sh.sku.split(':')[0]} x${sh.qty}</td><td>${sh.route}</td><td><span class="chip ${sh.status=='delayed'?'bad':sh.status=='rerouted'?'warn':'ok'}">${sh.status}</span> ${sh.eta_days}d</td></tr>`).join('')
 let d=s.agent.disruption, ds=document.getElementById('disr')
 if(s.env.disruptions.length) ds.innerHTML=s.env.disruptions.map(x=>`<div class="chip bad">${x.type}: ${x.desc}</div>`).join(' ')
 else if(d) ds.innerHTML=`<div class="chip warn">${d.type} @ ${d.target}</div>`
 else ds.innerHTML='<span class="chip ok">No disruption \u2014 healthy</span>'
 let sel=s.agent.selected||s.agent.current_plan
 document.getElementById('selected').innerHTML= sel? `<div class="cand sel"><b>&#9654; Selected: ${sel.type.toUpperCase()}</b> \u2014 ${sel.reason}<br><span class="mono">qty ${sel.qty} cost $${sel.cost} time ${sel.time_days}d carbon ${sel.carbon} score ${sel.score} ${sel.feasible===false?'\u26D4 infeasible':''}</span></div>` : '<div class="mono">No selection yet \u2014 run agent</div>'
 let cands=s.agent.candidates||[]
 document.getElementById('cands').innerHTML= cands.length? cands.slice(0,8).map(c=>{let isSel=sel&&c.reason==sel.reason;return `<div class="cand ${isSel?'sel':''}"><b>${c.type}</b> ${c.reason} ${isSel?'<span class="sel-badge">SELECTED</span>':''} <span class="chip ${c.feasible===false?'bad':'ok'}">${c.feasible===false?'rejected':'feasible'}</span><br><span class="mono">$${c.cost} ${c.time_days}d CO2 ${c.carbon} score ${c.score||'-'}</span></div>`}).join('') : '<span class="mono">No candidates \u2014 waiting for detection</span>'
 document.getElementById('timeline').innerHTML=(s.agent.timeline||[]).slice(-20).map(t=>`<div class="step ${t.phase}"><span class="badge">${t.phase}</span> <small class="mono">#${t.step}</small> ${t.msg}${t.detail?'<pre class="detail">'+JSON.stringify(t.detail,null,2)+'</pre>':''}</div>`).join('') || '<small>Empty</small>'
 let acts=s.agent.actions
 if(acts && acts.length){let a=acts[acts.length-1];let L=[];Object.keys(a.before.inventory).forEach(loc=>{Object.keys(a.before.inventory[loc]).forEach(sku=>{let b=a.before.inventory[loc][sku],c=(a.after.inventory[loc]||{})[sku];if(b!==c)L.push(loc+': '+sku.split(':')[1]+' '+b+' \u2192 '+c)})});document.getElementById('beforeAfter').textContent=(L.length?('Stock moved:\n'+L.join('\n')):'No stock change')+'\nResult: '+((a.result&&a.result.ok)?'worked':'did not work')}
 else document.getElementById('beforeAfter').textContent='No actions yet'
 let obj=(s.agent.objective||'balanced')
 let objLabel={'fastest':'Speed','lowest_cost':'Low Cost','lowest_carbon':'Low Pollution','balanced':'Balanced'}[obj]||obj
 document.getElementById('obj').textContent=objLabel; document.getElementById('objD').textContent=''
 document.getElementById('plans').textContent=(s.agent.timeline||[]).filter(t=>['DECIDE','REPLAN','OPTIMIZE'].includes(t.phase)).length
 document.getElementById('plansD').textContent=''
 document.getElementById('costSpent').textContent='$'+(s.env.budget_used||0); document.getElementById('costD').textContent=''
 ['F','C','P','B'].forEach(id=>{let el=document.getElementById('btn'+id);if(el)el.style.borderColor=(el.id==('btn'+{F:'fastest',C:'lowest_cost',P:'lowest_carbon',B:'balanced'}[id])&&obj=={F:'fastest',C:'lowest_cost',P:'lowest_carbon',B:'balanced'}[id])?'var(--red)':'var(--border)'})
}
async function scenario(n){await api('/api/scenario/'+n,{method:'POST'});await refresh()}
async function tick(){await api('/api/agent/tick',{method:'POST',body:JSON.stringify({objective:currentObjective})});await refresh()}
async function runAgent(){console.log('Run Agent clicked, objective:',currentObjective);await api('/api/agent/run',{method:'POST',body:JSON.stringify({objective:currentObjective})});await refresh()}
async function reset(){await api('/api/reset',{method:'POST'});await refresh()}
async function setObjective(o){currentObjective=o;await api('/api/agent/objective',{method:'POST',body:JSON.stringify({objective:o})});await refresh()}
function autoToggle(){let b=document.getElementById('autoBtn');if(auto){clearInterval(auto);auto=null;b.textContent='Auto: OFF'}else{auto=setInterval(refresh,1500);b.textContent='Auto: ON'}}
refresh(); setInterval(()=>{if(!auto) refresh()},3000)
