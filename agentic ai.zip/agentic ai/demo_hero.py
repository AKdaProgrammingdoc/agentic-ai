"""One-command deterministic hero demo. Requires the server running:
    python -m uvicorn main:app --host 127.0.0.1 --port 8000   (from backend/)
Run:  python demo_hero.py
"""
import json
import urllib.request

BASE = "http://127.0.0.1:8000"


def call(method, path, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        return json.loads(r.read().decode())


def show(tag, s):
    sel = (s["agent"]["selected"] or {}).get("reason", "—")
    print("%-28s state=%-16s selected=%s" % (tag, s["agent"]["state"], sel))
    return s


print("=== Autonomous Retail Supply Chain Recovery — hero demo ===")
show("reset", call("POST", "/api/reset"))
show("shipment delay injected", call("POST", "/api/scenario/shipment_delay"))
call("POST", "/api/agent/objective", {"objective": "fastest"})
show("RUN (fastest)", call("POST", "/api/agent/run", {"objective": "fastest"}))
show("SUPPLIER-B FAILURE injected", call("POST", "/api/scenario/supplier_b_failure"))
show("auto-replan tick", call("POST", "/api/agent/tick"))
show("ROUTE R2 BLOCKED injected", call("POST", "/api/scenario/route_r2_blocked"))
s = show("2nd auto-replan tick", call("POST", "/api/agent/tick"))
h = call("GET", "/api/history")
print("plan memory:", [(p["status"], p["summary"]) for p in h["plan_history"]])
print("tool calls:", len(h["tool_activity"]))
call("POST", "/api/agent/require_approval", {"require_approval": True})
print("approval gate:", call("POST", "/api/agent/tick")["agent"]["state"])
s = show("HUMAN APPROVED", call("POST", "/api/approve"))
v = s["agent"]["verification"][-1] if s["agent"]["verification"] else None
print("verification:", v)
print("=== DONE: %s ===" % s["agent"]["state"])
