# Autonomous Retail Supply Chain Recovery Agent

One agentic-AI backend wired to the approved existing UI (`frontend/` — **0 files changed**).

## Architecture

```
frontend/index.html (UNCHANGED, served by backend)
        |  GET /api/state (poll) · POST /api/scenario/* · /api/agent/tick|run · /api/reset
backend/main.py ── FastAPI, existing contract preserved + additive endpoints
backend/agent.py ── state machine + LLM tool-use loop + plan memory
backend/tools.py ── 13 real tools (deterministic, env is source of truth)
backend/simulation.py ── mutable logistics env (seeded, reproducible)
backend/llm.py ── OpenAI-compatible provider, function calling
```

Agent states: `IDLE → MONITORING → DISRUPTION_DETECTED → INVESTIGATING →
SIMULATING → OPTIMIZING → PLAN_READY → AWAITING_APPROVAL → EXECUTING →
VERIFYING → RECOVERED`, with `REPLANNING` / `FAILED` branches.
Failed or human-rejected plans are memorized and never retried in the episode.

## Run

```powershell
cd backend
pip install -r requirements.txt
python -m uvicorn main:app --host 127.0.0.1 --port 8000
# open http://127.0.0.1:8000
```

## Environment variables

| Var | Default | Meaning |
|---|---|---|
| `LLM_API_KEY` | — | Enables real LLM tool-calling reasoning. Without it the agent runs a clearly-labeled deterministic fallback (never faked). |
| `LLM_MODEL` | `gpt-4o-mini` | Chat-completions model |
| `LLM_BASE_URL` | `https://api.openai.com/v1` | OpenAI-compatible endpoint (Groq, Together, Ollama, …) |
| `AUTONOMOUS_LOOP` | `0` | `1` = server-side monitor detects + recovers with no UI clicks |
| `MONITOR_INTERVAL_SEC` | `5` | Autonomous loop interval |

## Demo (cascading failure, ~2 min)

```powershell
python demo_hero.py
```

Reset → Shipment Delay → fastest objective → Run → Supplier-B failure →
auto-replan → Route R2 blocked → 2nd auto-replan → approval gate →
approve → RECOVERED. Rejection path: `/api/reject` never mutates the env.

Or click it: **Shipment Delay → Run Agent (autonomous)** in the UI.

## Tests

```powershell
cd backend
python -m pytest test_agent.py -q   # 15 tests: env, tools, non-mutation,
                                     # optimization, failures, cascading replan,
                                     # memory, rejection, approval gate, LLM loop
```

## Key endpoints

Existing UI: `GET /api/state`, `POST /api/scenario/{name}`,
`POST /api/agent/tick|run`, `POST /api/reset`, `GET /api/health`.
Additive: `GET /api/monitor|environment|agent|history|analysis|llm|autonomy`,
`POST /api/agent/objective|require_approval`, `POST /api/approve|reject|execute`.
